const fs=require('fs');
const f=__dirname+'/pos.html';
const buf=fs.readFileSync(f);
// Show hex around the title to understand the corruption
const s=buf.toString('binary');
const idx=s.indexOf('RestoManager');
const chunk=buf.slice(idx+13,idx+50);
console.log('Hex after "RestoManager":',chunk.toString('hex'));
console.log('As latin1:',chunk.toString('latin1'));
console.log('As utf8:',chunk.toString('utf8'));
// Try: read as utf8, get codepoints
const u=buf.toString('utf8');
const ti=u.indexOf('RestoManager');
const sub=u.substring(ti+13,ti+30);
console.log('Unicode codepoints:',Array.from(sub).map(c=>c.charCodeAt(0).toString(16)));
