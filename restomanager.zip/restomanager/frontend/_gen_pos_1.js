// Generate correct pos.html from parts
const fs = require('fs');
const path = require('path');

const head = `<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>RestoManager \u2013 H\u1EC7 th\u1ED1ng F&B (Order &amp; Cashier)</title>
<script src="js/api.js"><\/script>
<script src="https://cdn.tailwindcss.com"><\/script>
<link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;500;600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
<script>
tailwind.config={theme:{extend:{colors:{"primary":"#004349","primary-container":"#0d5c63","on-primary":"#fff","on-primary-container":"#90d2da","secondary":"#006a66","secondary-container":"#84f2ec","on-secondary":"#fff","on-secondary-container":"#006f6b","tertiary":"#593300","tertiary-fixed":"#ffdcbc","on-tertiary-fixed":"#2c1700","error":"#ba1a1a","error-container":"#ffdad6","on-error":"#fff","on-error-container":"#93000a","surface":"#f9f9fc","surface-container":"#eeeef0","surface-container-low":"#f3f3f6","surface-container-high":"#e8e8ea","surface-container-highest":"#e2e2e5","surface-container-lowest":"#fff","surface-variant":"#e2e2e5","surface-dim":"#dadadc","on-surface":"#1a1c1e","on-surface-variant":"#3f484a","outline":"#6f797a","outline-variant":"#bfc8c9","inverse-surface":"#2f3133","inverse-on-surface":"#f0f0f3","background":"#f9f9fc","on-background":"#1a1c1e"},spacing:{"xs":"4px","sm":"8px","md":"16px","lg":"24px","xl":"32px","gutter":"16px","margin-mobile":"16px","touch-target":"48px"},fontFamily:{"h1":["Work Sans"],"h2":["Work Sans"],"body-md":["Work Sans"],"body-lg":["Work Sans"],"label-bold":["Inter"],"label-sm":["Inter"],"table-number":["Work Sans"]},fontSize:{"h1":["24px",{lineHeight:"32px",fontWeight:"600"}],"h2":["20px",{lineHeight:"28px",fontWeight:"600"}],"body-md":["16px",{lineHeight:"24px",fontWeight:"400"}],"label-bold":["14px",{lineHeight:"20px",letterSpacing:"0.02em",fontWeight:"600"}],"label-sm":["12px",{lineHeight:"16px",fontWeight:"500"}],"table-number":["28px",{lineHeight:"32px",fontWeight:"700"}]}}}}
<\/script>
<link href="css/pos.css" rel="stylesheet"/>
</head>
<body>
`;

const login = `
<!-- PAGE: LOGIN -->
<div id="pg-login" class="page active items-center justify-center p-4 bg-gradient-to-b from-[#004349] to-[#006a66]">
  <div class="w-full max-w-sm bg-white rounded-2xl shadow-2xl overflow-hidden">
    <div class="bg-[#004349] px-6 pt-8 pb-6 text-center">
      <div class="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3">
        <span class="material-symbols-outlined fill text-white" style="font-size:36px">restaurant</span>
      </div>
      <h1 class="text-white font-h1 text-h1">RestoManager</h1>
      <p class="text-white/70 text-sm mt-1">H\u1EC7 th\u1ED1ng qu\u1EA3n l\u00FD nh\u00E0 h\u00E0ng</p>
    </div>
    <div class="p-6 flex flex-col gap-4">
      <div class="flex flex-col gap-1">
        <label class="text-xs font-semibold text-on-surface-variant uppercase tracking-wider">T\u00EAn \u0111\u0103ng nh\u1EADp</label>
        <div class="relative">
          <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-outline text-[20px]">person</span>
          <input id="l-user" type="text" placeholder="Nh\u1EADp t\u00EAn \u0111\u0103ng nh\u1EADp" class="w-full pl-10 pr-4 h-12 border border-outline-variant rounded-xl text-on-surface bg-surface focus:outline-none focus:ring-2 focus:ring-primary font-body-md"/>
        </div>
      </div>
      <div class="flex flex-col gap-1">
        <label class="text-xs font-semibold text-on-surface-variant uppercase tracking-wider">M\u1EADt kh\u1EA9u</label>
        <div class="relative">
          <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-outline text-[20px]">lock</span>
          <input id="l-pass" type="password" placeholder="Nh\u1EADp m\u1EADt kh\u1EA9u" class="w-full pl-10 pr-12 h-12 border border-outline-variant rounded-xl text-on-surface bg-surface focus:outline-none focus:ring-2 focus:ring-primary font-body-md"/>
          <button onclick="togglePwd('l-pass',this)" class="absolute right-3 top-1/2 -translate-y-1/2 text-outline w-8 h-8 flex items-center justify-center"><span class="material-symbols-outlined text-[20px]">visibility_off</span></button>
        </div>
      </div>
      <div class="bg-surface-container rounded-xl p-3 text-xs text-on-surface-variant border border-outline-variant/50">
        <p class="font-semibold text-on-surface mb-1">T\u00E0i kho\u1EA3n demo:</p>
        <p>\u2022 <b class="text-primary">admin / 123</b> \u2192 Qu\u1EA3n tr\u1ECB vi\u00EAn</p>
        <p>\u2022 <b class="text-secondary">cashier / 123</b> \u2192 Thu ng\u00E2n</p>
        <p>\u2022 <b style="color:#593300">waiter / 123</b> \u2192 Nh\u00E2n vi\u00EAn Order</p>
      </div>
      <div id="l-err" class="hidden bg-error-container text-on-error-container rounded-xl p-3 text-sm font-semibold flex items-center gap-2"><span class="material-symbols-outlined text-[18px]">error</span>T\u00EAn \u0111\u0103ng nh\u1EADp ho\u1EB7c m\u1EADt kh\u1EA9u kh\u00F4ng \u0111\u00FAng.</div>
      <button onclick="doLogin()" class="w-full h-12 bg-primary hover:bg-primary-container text-white font-semibold rounded-xl flex items-center justify-center gap-2 transition active:scale-[.98] shadow-sm">
        \u0110\u0103ng nh\u1EADp <span class="material-symbols-outlined text-[20px]">login</span>
      </button>
    </div>
  </div>
</div>
`;

const waiterTables = `
<!-- PAGE: WAITER - S\u01A1 \u0111\u1ED3 b\u00E0n -->
<div id="pg-waiter-tables" class="page flex-col bg-background">
  <header class="bg-white border-b border-outline-variant/60 flex items-center justify-between px-4 h-14 sticky top-0 z-40 shadow-sm shrink-0">
    <div class="flex items-center gap-2">
      <span class="material-symbols-outlined fill text-primary">restaurant</span>
      <h1 class="font-semibold text-primary text-base">Nh\u00E0 h\u00E0ng POS</h1>
    </div>
    <div class="flex items-center gap-1">
      <button onclick="showLogoutDlg()" class="p-2 rounded-full hover:bg-surface-container text-on-surface-variant"><span class="material-symbols-outlined">logout</span></button>
    </div>
  </header>
  <div class="px-4 pt-4 pb-2 flex items-center justify-between">
    <div>
      <h2 class="font-h2 text-h2 text-on-surface">S\u01A1 \u0111\u1ED3 b\u00E0n</h2>
      <p class="text-sm text-on-surface-variant">Nh\u00E2n vi\u00EAn Order \u2013 ch\u1ECDn b\u00E0n \u0111\u1EC3 g\u1ECDi m\u00F3n</p>
    </div>
  </div>
  <div class="flex gap-2 px-4 pb-3 flex-wrap">
    <span class="pill-empty px-3 py-1 rounded-full text-xs font-semibold">Tr\u1ED1ng</span>
    <span class="pill-busy px-3 py-1 rounded-full text-xs font-semibold">C\u00F3 kh\u00E1ch</span>
    <span class="pill-pay px-3 py-1 rounded-full text-xs font-semibold">Ch\u1EDD TT</span>
  </div>
  <div class="flex gap-2 px-4 pb-3 overflow-x-auto no-scrollbar">
    <button class="chip on" onclick="waiterZone('all',this)">T\u1EA5t c\u1EA3</button>
    <button class="chip off" onclick="waiterZone('t1',this)">T\u1EA7ng 1</button>
    <button class="chip off" onclick="waiterZone('garden',this)">S\u00E2n v\u01B0\u1EDDn</button>
  </div>
  <div id="w-table-grid" class="scroll-content px-4 grid grid-cols-2 sm:grid-cols-3 gap-3"></div>
  <nav class="bnav">
    <button class="bnav-btn on" onclick="goPage('pg-waiter-tables','w-tables')"><span class="material-symbols-outlined fill">table_restaurant</span>S\u01A1 \u0111\u1ED3 b\u00E0n</button>
    <button class="bnav-btn" onclick="goPage('pg-waiter-orders','w-orders')"><span class="material-symbols-outlined">receipt_long</span>\u0110\u01A1n h\u00E0ng</button>
    <button class="bnav-btn" onclick="showLogoutDlg()"><span class="material-symbols-outlined">person</span>C\u00E1 nh\u00E2n</button>
  </nav>
</div>
`;

const waiterMenu = `
<!-- PAGE: WAITER - G\u1ECDi m\u00F3n -->
<div id="pg-waiter-menu" class="page flex-col bg-background">
  <header class="bg-white border-b border-outline-variant/60 flex items-center justify-between px-4 h-14 sticky top-0 z-40 shadow-sm shrink-0">
    <button onclick="goPage('pg-waiter-tables')" class="p-2 -ml-2 rounded-full hover:bg-surface-container text-primary"><span class="material-symbols-outlined">arrow_back</span></button>
    <div class="flex items-center gap-2"><span class="material-symbols-outlined text-primary fill">restaurant</span><h1 id="w-menu-title" class="font-semibold text-primary">G\u1ECDi m\u00F3n \u2013 B\u00E0n T1-01</h1></div>
    <button onclick="toggleSearch()" class="p-2 -mr-2 rounded-full hover:bg-surface-container text-primary"><span class="material-symbols-outlined">search</span></button>
  </header>
  <div id="w-search-bar" class="hidden bg-white border-b border-outline-variant px-4 py-2">
    <div class="flex items-center bg-surface-container rounded-xl px-3 h-10">
      <span class="material-symbols-outlined text-outline text-[18px] mr-2">search</span>
      <input id="w-search-input" type="text" placeholder="T\u00ECm m\u00F3n \u0103n..." class="flex-1 bg-transparent outline-none text-sm text-on-surface" oninput="filterBySearch(this.value)"/>
    </div>
  </div>
  <div class="flex gap-2 px-4 py-3 overflow-x-auto no-scrollbar border-b border-surface-variant sticky top-14 bg-white z-30">
    <button class="chip on" onclick="menuCat('all',this)">T\u1EA5t c\u1EA3</button>
    <button class="chip off" onclick="menuCat('starter',this)">Khai v\u1ECB</button>
    <button class="chip off" onclick="menuCat('main',this)">M\u00F3n ch\u00EDnh</button>
    <button class="chip off" onclick="menuCat('drink',this)">\u0110\u1ED3 u\u1ED1ng</button>
  </div>
  <div id="w-menu-list" class="flex-1 overflow-y-auto px-4 py-3 flex flex-col gap-3 pb-36"></div>
  <div id="w-cart-bar" class="hidden fixed bottom-0 left-0 right-0 z-50 bg-primary text-white px-4 py-3 flex items-center justify-between shadow-2xl" style="border-radius:20px 20px 0 0">
    <div class="flex items-center gap-2">
      <span class="material-symbols-outlined text-[20px]">shopping_cart</span>
      <span id="w-cart-count" class="font-semibold text-sm">1 m\u00F3n</span>
    </div>
    <span id="w-cart-total" class="font-bold">0 \u0111</span>
    <button onclick="goPage('pg-waiter-confirm')" class="bg-white text-primary font-bold text-sm px-4 py-2 rounded-full flex items-center gap-1 active:scale-95 transition">
      Xem \u0111\u01A1n <span class="material-symbols-outlined text-[16px]">arrow_forward</span>
    </button>
  </div>
</div>
`;

const waiterConfirm = `
<!-- PAGE: WAITER - X\u00E1c nh\u1EADn \u0111\u01A1n h\u00E0ng -->
<div id="pg-waiter-confirm" class="page flex-col bg-background">
  <header class="bg-white border-b border-outline-variant/60 flex items-center justify-between px-4 h-14 sticky top-0 z-40 shadow-sm shrink-0">
    <button onclick="goPage('pg-waiter-menu')" class="p-2 -ml-2 rounded-full hover:bg-surface-container text-primary"><span class="material-symbols-outlined">arrow_back</span></button>
    <h1 class="font-semibold text-primary">X\u00E1c nh\u1EADn \u0110\u01A1n h\u00E0ng</h1>
    <div class="w-10"></div>
  </header>
  <div class="mx-4 mt-4 p-4 bg-white rounded-2xl border border-outline-variant flex items-center gap-3 shadow-sm">
    <div class="w-10 h-10 bg-primary-container rounded-xl flex items-center justify-center"><span class="material-symbols-outlined text-on-primary-container fill">table_restaurant</span></div>
    <div>
      <p id="w-confirm-table" class="font-semibold text-on-surface">B\u00E0n T1-01</p>
      <p class="text-xs text-on-surface-variant">\u0110ang ph\u1EE5c v\u1EE5</p>
    </div>
    <div class="ml-auto">
      <span class="text-xs text-on-surface-variant italic">Ki\u1EC3m tra tr\u01B0\u1EDBc khi g\u1EEDi</span>
    </div>
  </div>
  <div id="w-confirm-list" class="flex-1 overflow-y-auto px-4 py-4 flex flex-col gap-3 pb-40"></div>
  <div class="fixed bottom-0 left-0 right-0 bg-white border-t border-outline-variant px-4 py-4 z-40 flex flex-col gap-3" style="border-radius:20px 20px 0 0;box-shadow:0 -4px 24px rgba(0,0,0,.08)">
    <div class="flex justify-between items-center">
      <span class="text-on-surface-variant font-label-bold text-label-bold">T\u1ED5ng c\u1ED9ng</span>
      <span id="w-confirm-total" class="font-table-number text-table-number text-primary">0 \u0111</span>
    </div>
    <div class="bg-surface-container-low rounded-xl p-3 flex items-center gap-2 text-sm text-on-surface-variant">
      <span class="material-symbols-outlined text-[18px] text-secondary">info</span>
      Order s\u1EBD g\u1EEDi \u0111\u1EBFn b\u1EBFp v\u00E0 thu ng\u00E2n
    </div>
    <button onclick="sendOrder()" class="w-full h-12 bg-primary text-white font-bold rounded-xl flex items-center justify-center gap-2 shadow-sm active:scale-[.98] transition">
      <span class="material-symbols-outlined">send</span>G\u1EEDi Order v\u1EC1 Thu ng\u00E2n
    </button>
  </div>
</div>
`;

const waiterOrders = `
<!-- PAGE: WAITER - Danh s\u00E1ch \u0111\u01A1n h\u00E0ng -->
<div id="pg-waiter-orders" class="page flex-col bg-background">
  <header class="bg-white border-b border-outline-variant/60 flex items-center justify-between px-4 h-14 sticky top-0 z-40 shadow-sm shrink-0">
    <div class="flex items-center gap-2"><span class="material-symbols-outlined fill text-primary">restaurant</span><h1 class="font-semibold text-primary">\u0110\u01A1n h\u00E0ng c\u1EE7a t\u00F4i</h1></div>
  </header>
  <div id="w-orders-list" class="scroll-content px-4 py-4 flex flex-col gap-3"></div>
  <nav class="bnav">
    <button class="bnav-btn" onclick="goPage('pg-waiter-tables')"><span class="material-symbols-outlined">table_restaurant</span>S\u01A1 \u0111\u1ED3 b\u00E0n</button>
    <button class="bnav-btn on" onclick="goPage('pg-waiter-orders','w-orders')"><span class="material-symbols-outlined fill">receipt_long</span>\u0110\u01A1n h\u00E0ng</button>
    <button class="bnav-btn" onclick="showLogoutDlg()"><span class="material-symbols-outlined">person</span>C\u00E1 nh\u00E2n</button>
  </nav>
</div>
`;

// Write part 1
fs.writeFileSync(path.join(__dirname, '_pos_parts.json'), JSON.stringify({
  head, login, waiterTables, waiterMenu, waiterConfirm, waiterOrders
}));
console.log('Part 1 written');
