// ═══════════════════════════════════════════════════════
//  RestoManager – POS Cashier Module
//  (tables, order detail, edit items, order list)
// ═══════════════════════════════════════════════════════

async function initCashier(){
  await loadMenuFromApi();
  await loadTablesFromApi();
  await loadOrdersFromApi({status:'pending,serving'});
  await loadPaidOrdersFromApi();
  refreshCashierTables();
  renderCashierOrders();
  updateCashierStats();
}

function refreshCashierTables(zone='all'){
  const grid=document.getElementById('c-table-grid');
  const filtered=zone==='all'?TABLES:TABLES.filter(t=>t.zone===zone);
  const pendingForTable={};
  orders.filter(o=>o.status==='pending').forEach(o=>{
    if(!pendingForTable[o.tableId]) pendingForTable[o.tableId]=0;
    pendingForTable[o.tableId]+=o.total;
  });
  grid.innerHTML=filtered.map(t=>{
    const cls=t.status==='busy'?'pill-busy':t.status==='pay'?'pill-pay':'pill-empty';
    const lbl=t.status==='busy'?'Có khách':t.status==='pay'?'Chờ TT':'Trống';
    const hasPending=pendingForTable[t.id];
    const clickable=t.status!=='empty';
    return `<div class="card p-4 flex flex-col gap-3 ${clickable?'':'opacity-60 pointer-events-none'}" onclick="openCashierDetail('${t.id}')">
      <div class="flex items-center justify-between">
        <span class="font-bold text-on-surface text-lg">${t.id}</span>
        <span class="${cls} text-xs font-semibold px-2 py-0.5 rounded-full">${lbl}</span>
      </div>
      <div class="flex items-center gap-1 text-xs text-on-surface-variant"><span class="material-symbols-outlined text-[14px]">group</span>${t.cap} chỗ</div>
      ${t.status!=='empty'?`
        <div class="flex justify-between text-xs">
          <span class="text-on-surface-variant flex items-center gap-0.5"><span class="material-symbols-outlined text-[13px]">schedule</span>${t.mins}ph</span>
          <span class="font-bold text-primary">${fmt(t.spent)}</span>
        </div>
        ${hasPending?`<div class="bg-tertiary-fixed/60 text-tertiary rounded-xl px-2 py-1 text-xs font-semibold flex items-center gap-1"><span class="material-symbols-outlined text-[14px]">notifications</span>Đơn mới: ${fmt(hasPending)}</div>`:''}
      `:`<div class="text-xs text-on-surface-variant">Trống</div>`}
    </div>`;
  }).join('');
}

async function cashierZone(zone,btn){
  document.querySelectorAll('#pg-cashier-tables .chip').forEach(b=>{b.className='chip off';});
  btn.className='chip on';
  await loadTablesFromApi();
  refreshCashierTables(zone);
}

async function openCashierDetail(tableId){
  currentTableId=tableId;
  const table=TABLES.find(t=>t.id===tableId);
  currentTableDbId=table?table.dbId:null;
  if(currentTableDbId){
    try{ currentOpenOrder=await Api.getOpenOrderForTable(currentTableDbId); }catch(_){currentOpenOrder=null;}
  } else { currentOpenOrder=null; }
  const tableOrders=orders.filter(o=>o.tableId===tableId&&o.status!=='paid');
  document.getElementById('c-detail-title').textContent=`Chi tiết – Bàn ${tableId}`;
  document.getElementById('c-detail-table-name').textContent=`Bàn ${tableId}`;
  document.getElementById('c-detail-time').textContent=table?`${table.mins} phút`:'–';
  document.getElementById('c-detail-guests').textContent=table?`${table.cap} khách`:'–';
  const allItems={};
  tableOrders.forEach(o=>{o.items.forEach(i=>{
    if(!allItems[i.id]) allItems[i.id]={...i,qty:0};
    allItems[i.id].qty+=i.qty;
  });});
  const items=Object.values(allItems);
  const sub=items.reduce((s,i)=>s+i.price*i.qty,0);
  const vat=Math.round(sub*0.08);
  const total=sub+vat;
  document.getElementById('c-subtotal').textContent=fmt(sub);
  document.getElementById('c-vat').textContent=fmt(vat);
  document.getElementById('c-total').textContent=fmt(total);
  const list=document.getElementById('c-detail-items');
  const addMoreBtn = currentRole==='cashier' && currentOpenOrder && currentOpenOrder.id
    ? `<button onclick="cashierAddMore()" class="w-full h-11 mb-3 bg-primary text-white text-sm font-semibold rounded-xl flex items-center justify-center gap-2 shadow-sm"><span class="material-symbols-outlined text-[18px]">add</span> Thêm món vào đơn</button>` : '';
  if(items.length===0){
    list.innerHTML = addMoreBtn + '<div class="text-center text-on-surface-variant py-16"><span class="material-symbols-outlined text-6xl block mb-3">receipt_long</span><p>Chưa có đơn hàng nào từ bàn này.</p></div>';
  } else {
    const isEditable = (currentRole==='cashier' || currentRole==='admin');
    list.innerHTML = addMoreBtn + tableOrders.map(o=>`
      <div class="bg-white rounded-2xl border border-outline-variant shadow-sm overflow-hidden">
        <div class="px-4 py-3 bg-surface-container-low flex items-center justify-between border-b border-outline-variant">
          <span class="font-semibold text-on-surface text-sm">${o.id}</span>
          <span class="text-xs text-on-surface-variant flex items-center gap-1"><span class="material-symbols-outlined text-[13px]">schedule</span>${o.time}</span>
        </div>
        ${o.items.map(i=>`
          <div class="flex items-center gap-3 px-4 py-3 border-b border-outline-variant/50 last:border-0">
            <div class="w-10 h-10 bg-surface-container rounded-xl flex items-center justify-center text-2xl shrink-0">${i.emoji}</div>
            <div class="flex-1 min-w-0">
              <p class="font-semibold text-on-surface text-sm truncate">${i.name}</p>
              <p class="text-xs text-on-surface-variant">${fmt(i.price)} × ${i.qty} = <span class="text-primary font-semibold">${fmt(i.price*i.qty)}</span></p>
            </div>
            ${isEditable ? `
              <div class="flex items-center gap-1 shrink-0">
                <button onclick="cashierItemDec('${o.dbId}','${i.oi_id}',${i.qty})" class="w-8 h-8 rounded-full bg-surface-container text-on-surface flex items-center justify-center"><span class="material-symbols-outlined text-[18px]">remove</span></button>
                <span class="w-6 text-center font-bold text-on-surface text-sm">${i.qty}</span>
                <button onclick="cashierItemInc('${o.dbId}','${i.oi_id}',${i.qty})" class="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center"><span class="material-symbols-outlined text-[18px]">add</span></button>
                <button onclick="cashierItemDelete('${o.dbId}','${i.oi_id}','${(i.name||'').replace(/'/g,'&#39;')}')" class="w-8 h-8 rounded-full bg-error-container text-on-error-container flex items-center justify-center ml-1"><span class="material-symbols-outlined text-[18px]">delete</span></button>
              </div>` : `<span class="font-bold text-primary text-sm shrink-0">${fmt(i.price*i.qty)}</span>`}
          </div>`).join('')}
      </div>`).join('');
  }
  goPage('pg-cashier-detail');
}

async function cashierItemInc(orderId, itemId, currentQty){
  try{
    await Api.updateOrderItem(orderId, itemId, { quantity: Number(currentQty)+1 });
    await loadOrdersFromApi({});
    await openCashierDetail(currentTableId);
  }catch(err){ toast(err.message||'Cập nhật thất bại','error'); }
}
async function cashierItemDec(orderId, itemId, currentQty){
  const q = Number(currentQty);
  try{
    if(q<=1){ await Api.removeOrderItem(orderId, itemId); }
    else { await Api.updateOrderItem(orderId, itemId, { quantity: q-1 }); }
    await loadOrdersFromApi({});
    await openCashierDetail(currentTableId);
  }catch(err){ toast(err.message||'Cập nhật thất bại','error'); }
}
async function cashierItemDelete(orderId, itemId, name){
  if(!confirm(`Xoá "${name}" khỏi đơn?`)) return;
  try{
    await Api.removeOrderItem(orderId, itemId);
    toast('Đã xoá món','check_circle');
    await loadOrdersFromApi({});
    await openCashierDetail(currentTableId);
  }catch(err){ toast(err.message||'Xoá thất bại','error'); }
}
function cashierAddMore(){
  cashierEditingMode = true;
  openWaiterMenu(currentTableId);
}

function renderCashierOrders(){
  const list=document.getElementById('c-orders-list');
  const all=[...orders].reverse();
  if(all.length===0){
    list.innerHTML='<div class="text-center text-on-surface-variant py-16"><span class="material-symbols-outlined text-6xl block mb-3">receipt_long</span><p>Chưa có đơn hàng nào.</p></div>';return;
  }
  list.innerHTML=all.map(o=>`
    <div class="card p-4 flex flex-col gap-3">
      <div class="flex items-center justify-between">
        <div class="flex items-center gap-2"><span class="material-symbols-outlined text-primary text-[18px]">table_restaurant</span><span class="font-bold text-on-surface">Bàn ${o.tableId}</span><span class="text-xs text-on-surface-variant">${o.id}</span></div>
        <span class="text-xs ${o.status==='paid'?'bg-secondary-container text-on-secondary-container':o.status==='pending'?'bg-tertiary-fixed text-tertiary':''} px-3 py-0.5 rounded-full font-semibold">
          ${o.status==='paid'?'Đã TT':o.status==='pending'?'Chờ TT':'–'}
        </span>
      </div>
      <div class="flex gap-1 flex-wrap">${o.items.map(i=>`<span class="bg-surface-container px-2 py-0.5 rounded-full text-xs">${i.emoji} ${i.name} x${i.qty}</span>`).join('')}</div>
      <div class="flex justify-between items-center border-t border-outline-variant pt-2">
        <span class="text-xs text-on-surface-variant flex items-center gap-1"><span class="material-symbols-outlined text-[13px]">schedule</span>${o.time} • ${o.waiter}</span>
        <span class="font-bold text-primary">${fmt(o.total)}</span>
      </div>
      ${o.status==='pending'?`<button onclick="openCashierDetail('${o.tableId}')" class="w-full h-9 border border-primary text-primary text-sm font-semibold rounded-xl hover:bg-primary hover:text-white transition">Xem & Thanh toán</button>`:''}
    </div>`).join('');
}

function _refreshCashierIfActive(){
  if(document.getElementById('pg-cashier-tables').classList.contains('active'))
    refreshCashierTables();
}
