// ═══════════════════════════════════════════════════════
//  RestoManager – POS Authentication
// ═══════════════════════════════════════════════════════

async function doLogin(){
  const u=document.getElementById('l-user').value.trim();
  const p=document.getElementById('l-pass').value;
  if(!u||!p){document.getElementById('l-err').classList.remove('hidden');return;}
  try{
    const data=await Api.login(u,p);
    Api.setToken(data.token);
    Api.setUser(data.user);
    document.getElementById('l-err').classList.add('hidden');
    currentUser={username:data.user.username,name:data.user.full_name,role:data.user.role,id:data.user.id};
    currentRole=currentUser.role;
    if(currentRole==='admin'){
      window.location.href='admin.html';
      return;
    }
    if(currentRole==='waiter'){await initWaiter();goPage('pg-waiter-tables');}
    else {await initCashier();goPage('pg-cashier-tables');}
  }catch(err){
    document.getElementById('l-err').textContent && (document.getElementById('l-err').textContent='');
    const errEl=document.getElementById('l-err');
    errEl.innerHTML='<span class="material-symbols-outlined text-[18px]">error</span>'+(err.message||'Đăng nhập thất bại');
    errEl.classList.remove('hidden');
  }
}

async function doLogout(){
  closeDlg('logout-dlg');
  try{await Api.logout();}catch(_){}
  Api.clearToken();
  currentUser=null;currentRole=null;cart={};currentTableId=null;
  document.getElementById('l-user').value='';
  document.getElementById('l-pass').value='';
  goPage('pg-login');
  toast('Đã đăng xuất','logout');
}

// Enter key handlers for login form
document.getElementById('l-pass').addEventListener('keydown',e=>{if(e.key==='Enter')doLogin();});
document.getElementById('l-user').addEventListener('keydown',e=>{if(e.key==='Enter')document.getElementById('l-pass').focus();});
