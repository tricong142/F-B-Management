// ═══════════════════════════════════════════════════════
//  RestoManager – POS Utilities (shared helpers)
// ═══════════════════════════════════════════════════════

function fmt(n){return n.toLocaleString('vi-VN')+'đ';}

function togglePwd(id,btn){
  const inp=document.getElementById(id);
  const ic=btn.querySelector('.material-symbols-outlined');
  inp.type=inp.type==='password'?'text':'password';
  ic.textContent=inp.type==='password'?'visibility_off':'visibility';
}

let _tt=null;
function toast(msg,icon='check_circle'){
  const t=document.getElementById('toast');
  document.getElementById('toast-msg').textContent=msg;
  document.getElementById('toast-icon').textContent=icon;
  t.classList.add('show');
  if(_tt) clearTimeout(_tt);
  _tt=setTimeout(()=>t.classList.remove('show'),2500);
}

// ═══════════════════════════ DIALOGS ══════
function showLogoutDlg(){document.getElementById('logout-dlg').classList.add('open');}
function closeDlg(id){document.getElementById(id).classList.remove('open');}

// Close overlays on outside click
document.querySelectorAll('.overlay').forEach(ov=>{
  ov.addEventListener('click',e=>{if(e.target===ov) ov.classList.remove('open');});
});
