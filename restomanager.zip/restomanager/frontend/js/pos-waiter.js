// ═══════════════════════════════════════════════════════
//  RestoManager – POS Waiter Module
//  (tables, menu, cart, order confirm, order list)
// ═══════════════════════════════════════════════════════

// ═══════════════════════════ WAITER INIT ══════
async function initWaiter(){
  await loadMenuFromApi();
  await loadTablesFromApi();
  await loadOrdersFromApi({waiter_id:currentUser?.id, status:'pending,serving'});
  renderWaiterTables();
  renderWaiterOrders();
}

function renderWaiterTables(zone='all'){
  const grid=document.getElementById('w-table-grid');
  const filtered=zone==='all'?TABLES:TABLES.filter(t=>t.zone===zone);
  grid.innerHTML=filtered.map(t=>{
    const cls=t.status==='busy'?'pill-busy':t.status==='pay'?'pill-pay':'pill-empty';
    const lbl=t.status==='busy'?'Có khách':t.status==='pay'?'Chờ TT':'Trống';
    const canOrder=t.status!=='pay';
    return `<div class="card p-4 flex flex-col gap-3" onclick="${canOrder?`openWaiterMenu('${t.id}')`:`toast('Bàn đang chờ thanh toán','payments')`}">
      <div class="flex items-center justify-between">
        <span class="font-bold text-on-surface text-lg">${t.id}</span>
        <span class="${cls} text-xs font-semibold px-2 py-0.5 rounded-full">${lbl}</span>
      </div>
      <div class="flex items-center gap-1 text-xs text-on-surface-variant"><span class="material-symbols-outlined text-[14px]">group</span>${t.cap} chỗ</div>
      ${t.status!=='empty'?`<div class="flex items-center justify-between text-xs">
        <span class="text-on-surface-variant flex items-center gap-1"><span class="material-symbols-outlined text-[13px]">schedule</span>${t.mins} phút</span>
        <span class="font-semibold text-primary">${fmt(t.spent)}</span>
      </div>`:'<div class="text-xs text-on-surface-variant">Chưa có khách</div>'}
      ${canOrder&&t.status!=='empty'?`<button class="w-full h-9 bg-primary text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-1"><span class="material-symbols-outlined text-[16px]">add</span>Thêm món</button>`:''}
    </div>`;
  }).join('');
}

async function waiterZone(zone,btn){
  document.querySelectorAll('#pg-waiter-tables .chip').forEach(b=>{b.className='chip off';});
  btn.className='chip on';
  await loadTablesFromApi();
  renderWaiterTables(zone);
}

async function openWaiterMenu(tableId){
  currentTableId=tableId;
  const t=TABLE_BY_CODE[tableId];
  currentTableDbId=t?t.dbId:null;
  // Try to fetch existing open order so waiter can ADD to it
  currentOpenOrder=null;
  try{
    if(currentTableDbId){
      currentOpenOrder=await Api.getOpenOrderForTable(currentTableDbId);
    }
  }catch(_){}
  document.getElementById('w-menu-title').textContent=`Gọi món – Bàn ${tableId}`;
  document.getElementById('w-confirm-table').textContent=`Bàn ${tableId}`;
  currentMenuCat='all';
  cart={};
  renderMenuList();
  goPage('pg-waiter-menu');
  updateCartBar();
}

// ═══════════════════════════ MENU ══════
function renderMenuList(){
  const list=document.getElementById('w-menu-list');
  let items=MENU_ITEMS;
  if(currentMenuCat!=='all') items=items.filter(m=>m.cat===currentMenuCat);
  if(currentMenuSearch) items=items.filter(m=>m.name.toLowerCase().includes(currentMenuSearch.toLowerCase()));
  if(items.length===0){list.innerHTML='<div class="text-center text-on-surface-variant py-12"><span class="material-symbols-outlined text-5xl block mb-2">search_off</span>Không tìm thấy món</div>';return;}
  list.innerHTML=items.map(m=>{
    const qty=cart[m.id]||0;
    return `<div class="bg-white rounded-2xl border ${qty>0?'border-primary/40 shadow-md':'border-outline-variant'} flex items-center gap-3 p-3 transition">
      <div class="w-20 h-20 rounded-xl bg-surface-container flex items-center justify-center text-4xl shrink-0">${m.emoji}</div>
      <div class="flex-1 min-w-0">
        <p class="font-semibold text-on-surface text-sm leading-tight">${m.name}</p>
        <p class="text-xs text-on-surface-variant mt-0.5 line-clamp-1">${m.desc}</p>
        <p class="font-bold text-primary text-sm mt-1">${fmt(m.price)}</p>
      </div>
      <div class="shrink-0">
        ${qty===0
          ?`<button onclick="addToCart('${m.id}')" class="qty-btn bg-primary text-white shadow-sm"><span class="material-symbols-outlined text-[20px]">add</span></button>`
          :`<div class="flex items-center gap-2">
              <button onclick="removeFromCart('${m.id}')" class="qty-btn bg-surface-container text-on-surface"><span class="material-symbols-outlined text-[20px]">remove</span></button>
              <span class="w-7 text-center font-bold text-on-surface">${qty}</span>
              <button onclick="addToCart('${m.id}')" class="qty-btn bg-primary text-white shadow-sm"><span class="material-symbols-outlined text-[20px]">add</span></button>
            </div>`
        }
      </div>
    </div>`;
  }).join('');
}

function menuCat(cat,btn){
  currentMenuCat=cat;
  document.querySelectorAll('#pg-waiter-menu .chip').forEach(b=>{b.className='chip off';});
  btn.className='chip on';
  renderMenuList();
}

function filterBySearch(val){currentMenuSearch=val;renderMenuList();}

let searchVisible=false;
function toggleSearch(){
  searchVisible=!searchVisible;
  document.getElementById('w-search-bar').classList.toggle('hidden',!searchVisible);
  if(searchVisible) document.getElementById('w-search-input').focus();
  else{document.getElementById('w-search-input').value='';currentMenuSearch='';renderMenuList();}
}

function addToCart(id){
  cart[id]=(cart[id]||0)+1;
  renderMenuList();updateCartBar();
}
function removeFromCart(id){
  if(cart[id]>1) cart[id]--;
  else delete cart[id];
  renderMenuList();updateCartBar();
}

function cartTotal(){
  return Object.entries(cart).reduce((s,[id,q])=>{
    const m=MENU_ITEMS.find(x=>x.id==id);
    return s+(m?m.price*q:0);
  },0);
}
function cartCount(){return Object.values(cart).reduce((s,q)=>s+q,0);}

function updateCartBar(){
  const bar=document.getElementById('w-cart-bar');
  const count=cartCount();
  bar.classList.toggle('hidden',count===0);
  document.getElementById('w-cart-count').textContent=`${count} món`;
  document.getElementById('w-cart-total').textContent=fmt(cartTotal());
}

// ═══════════════════════════ CONFIRM ORDER ══════
function renderConfirmList(){
  const list=document.getElementById('w-confirm-list');
  const entries=Object.entries(cart).map(([id,qty])=>{
    const m=MENU_ITEMS.find(x=>x.id==id);
    if(!m) return '';
    return `<div class="bg-white rounded-2xl border border-outline-variant p-4 shadow-sm">
      <div class="flex items-center gap-3">
        <div class="w-12 h-12 rounded-xl bg-surface-container flex items-center justify-center text-3xl shrink-0">${m.emoji}</div>
        <div class="flex-1">
          <p class="font-semibold text-on-surface">${m.name}</p>
          <p class="text-sm text-primary font-bold mt-0.5">${fmt(m.price)}</p>
        </div>
      </div>
      <div class="flex items-center justify-between mt-3 pt-3 border-t border-outline-variant">
        <div class="flex items-center gap-3">
          <button onclick="confirmRemove('${m.id}')" class="qty-btn bg-surface-container text-on-surface"><span class="material-symbols-outlined text-[20px]">remove</span></button>
          <span class="font-bold text-on-surface w-6 text-center">${qty}</span>
          <button onclick="confirmAdd('${m.id}')" class="qty-btn bg-primary text-white"><span class="material-symbols-outlined text-[20px]">add</span></button>
        </div>
        <span class="font-bold text-on-surface">${fmt(m.price*qty)}</span>
      </div>
    </div>`;
  });
  list.innerHTML=entries.join('');
  document.getElementById('w-confirm-total').textContent=fmt(cartTotal());
}

function confirmAdd(id){cart[id]=(cart[id]||0)+1;renderConfirmList();updateCartBar();}
function confirmRemove(id){
  if(cart[id]>1) cart[id]--;
  else delete cart[id];
  renderConfirmList();updateCartBar();
  if(cartCount()===0) goPage('pg-waiter-menu');
}

// Hook page navigation: refresh data when switching tabs
const _origGoPage=goPage;
goPage=function(id,...args){
  _origGoPage(id,...args);
  if(id==='pg-waiter-confirm') renderConfirmList();
  if(id==='pg-waiter-tables'){ loadTablesFromApi().then(()=>renderWaiterTables()); }
  if(id==='pg-waiter-orders'){ loadOrdersFromApi({waiter_id:currentUser?.id}).then(()=>renderWaiterOrders()); }
  if(id==='pg-cashier-tables'){ loadTablesFromApi().then(()=>refreshCashierTables()); }
  if(id==='pg-cashier-orders'){ loadOrdersFromApi({}).then(()=>renderCashierOrders()); }
  if(id==='pg-cashier-stats'){ updateCashierStats(); }
};

async function sendOrder(){
  if(cartCount()===0){toast('Chưa có món nào!','warning');return;}
  const table=TABLES.find(t=>t.id===currentTableId);
  const apiItems=Object.entries(cart).map(([id,qty])=>{
    const m=MENU_ITEMS.find(x=>x.id==id);
    return {menu_item_id:m.id,item_name:m.name,quantity:qty,price:m.price};
  });
  const total=cartTotal();
  try{
    if(currentOpenOrder && currentOpenOrder.id){
      // Add items to existing order
      await Api.addOrderItems(currentOpenOrder.id, apiItems);
    } else {
      await Api.createOrder({
        table_id: currentTableDbId,
        table_code: currentTableId,
        waiter_name: currentUser?.name || 'NV Order',
        items: apiItems,
      });
    }
    document.getElementById('order-sent-msg').textContent=`Bàn ${currentTableId} – ${apiItems.length} món – ${fmt(total)}`;
    document.getElementById('order-sent-dlg').classList.add('open');
    cart={};updateCartBar();
    await loadTablesFromApi();
    await loadOrdersFromApi({waiter_id:currentUser?.id, status:'pending,serving'});
    renderWaiterOrders();
    renderWaiterTables();
  }catch(err){
    toast(err.message||'Gửi order thất bại','error');
  }
}

async function afterOrderSent(){
  closeDlg('order-sent-dlg');
  await loadTablesFromApi();
  if (cashierEditingMode) {
    // Quay lại trang chi tiết đơn của cashier
    cashierEditingMode = false;
    await loadOrdersFromApi({});
    await openCashierDetail(currentTableId);
    return;
  }
  goPage('pg-waiter-tables');
  renderWaiterTables();
}

// ═══════════════════════════ WAITER ORDERS ══════
function renderWaiterOrders(){
  const list=document.getElementById('w-orders-list');
  const myOrders=orders.filter(o=>o.waiter===(currentUser?.name||'NV Order'));
  if(myOrders.length===0){
    list.innerHTML='<div class="text-center text-on-surface-variant py-16"><span class="material-symbols-outlined text-6xl block mb-3">receipt_long</span><p>Chưa có đơn hàng nào.</p></div>';return;
  }
  list.innerHTML=[...myOrders].reverse().map(o=>`
    <div class="card p-4 flex flex-col gap-3">
      <div class="flex items-center justify-between">
        <div class="flex items-center gap-2"><span class="material-symbols-outlined text-primary text-[18px]">table_restaurant</span><span class="font-bold text-on-surface">Bàn ${o.tableId}</span></div>
        <span class="text-xs ${o.status==='paid'?'bg-secondary-container text-on-secondary-container':o.status==='pending'?'bg-primary-container text-on-primary-container':'bg-surface-container-highest text-on-surface-variant'} px-3 py-0.5 rounded-full font-semibold">
          ${o.status==='paid'?'Đã TT':o.status==='pending'?'Chờ bếp':'Đang làm'}
        </span>
      </div>
      <div class="flex gap-2 text-xs text-on-surface-variant">
        <span class="flex items-center gap-1"><span class="material-symbols-outlined text-[13px]">schedule</span>${o.time}</span>
        <span class="flex items-center gap-1"><span class="material-symbols-outlined text-[13px]">receipt</span>${o.id}</span>
      </div>
      <div class="flex flex-wrap gap-1">
        ${o.items.map(i=>`<span class="bg-surface-container px-2 py-0.5 rounded-full text-xs">${i.emoji} ${i.name} x${i.qty}</span>`).join('')}
      </div>
      <div class="flex justify-between items-center border-t border-outline-variant pt-2">
        <span class="text-xs text-on-surface-variant">${o.items.length} món</span>
        <span class="font-bold text-primary">${fmt(o.total)}</span>
      </div>
    </div>
  `).join('');
}
