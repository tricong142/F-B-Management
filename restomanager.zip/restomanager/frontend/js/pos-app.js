// ═══════════════════════════════════════════════════════
//  RestoManager – POS App Core (state, router, data loaders)
// ═══════════════════════════════════════════════════════

// ═══════════════════════════════════════ DATA (API-backed) ══════
let MENU_ITEMS=[];
let TABLES=[];
let TABLE_BY_CODE={};

// State
let currentUser=null;
let currentRole=null;
let currentTableId=null;     // code of table (e.g. T1-01)
let currentTableDbId=null;   // UUID of table
let currentOpenOrder=null;   // server order object (or null)
let currentMenuCat='all';
let currentMenuSearch='';
let cart={};                 // { menuItemId: qty }
let orders=[];               // server-loaded orders cache (for current view)
let paidOrders=[];
let payMethod='cash';
let cashierEditingMode=false;  // true khi cashier dùng pg-waiter-menu để thêm món

async function loadMenuFromApi(){
  const items=await Api.listMenu({active:'true'});
  MENU_ITEMS=items.map(it=>({
    id:it.id, name:it.name, cat:it.category_code||'main',
    price:Number(it.price), emoji:it.emoji||'🍽', desc:it.description||'',
    image_url:it.image_url||null,
  }));
}
async function loadTablesFromApi(){
  const list=await Api.listTables({with_status:'true'});
  TABLES=list.map(t=>{
    let status=t.status||'empty';
    return {
      id:t.code, dbId:t.id, zone:t.zone, cap:t.capacity,
      status, spent:Number(t.spent||0), mins:t.mins||0,
      open_order_id:t.open_order_id, open_order_code:t.open_order_code,
    };
  });
  TABLE_BY_CODE={};
  TABLES.forEach(t=>TABLE_BY_CODE[t.id]=t);
}
async function loadOrdersFromApi(filter={}){
  // For current cashier "today" view we just fetch all
  const list=await Api.listOrders(filter);
  orders=list.map(o=>({
    id:o.code, dbId:o.id, tableId:o.table_code,
    items:(o.items||[]).map(i=>({
      oi_id: i.id,                   // order_items.id (UUID) — dùng để sửa/xoá
      mi_id: i.menu_item_id || null, // menu_items.id (UUID)
      id:    i.menu_item_id || i.id, // legacy
      name:  i.item_name,
      qty:   i.quantity,
      price: Number(i.price),
      emoji: (MENU_ITEMS.find(m=>m.id===i.menu_item_id)?.emoji)||'🍽',
    })),
    total:Number(o.total_amount),
    time:new Date(o.created_at).toLocaleTimeString('vi-VN',{hour:'2-digit',minute:'2-digit'}),
    status:o.status==='completed'?'paid':o.status,
    waiter:o.waiter_name,
  }));
  return orders;
}
async function loadPaidOrdersFromApi(){
  const today=new Date(new Date().setHours(0,0,0,0)).toISOString();
  const list=await Api.listInvoices({from:today});
  paidOrders=list.map(inv=>({
    invId:'#'+inv.code, tableId:inv.table_code,
    total:Number(inv.final_amount),
    time:new Date(inv.created_at).toLocaleTimeString('vi-VN',{hour:'2-digit',minute:'2-digit'}),
    payment_method:inv.payment_method,
    items:inv.items||[],
  }));
}

// ═══════════════════════════ PAGE ROUTER ══════
function goPage(id){
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  const el=document.getElementById(id);
  if(el){el.classList.add('active');window.scrollTo(0,0);}
}

// Auto-resume session if token still valid
window.addEventListener('DOMContentLoaded', async ()=>{
  if(!Api.getToken()) return;
  try{
    const me=await Api.me();
    currentUser={username:me.username,name:me.full_name,role:me.role,id:me.id};
    currentRole=me.role;
    if(me.role==='admin'){window.location.href='admin.html';return;}
    if(me.role==='waiter'){await initWaiter();goPage('pg-waiter-tables');}
    else {await initCashier();goPage('pg-cashier-tables');}
  }catch(_){
    Api.clearToken();
  }
});
