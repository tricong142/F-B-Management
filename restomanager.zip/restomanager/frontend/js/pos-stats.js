// ═══════════════════════════════════════════════════════
//  RestoManager – POS Stats Module
//  (cashier shift statistics)
// ═══════════════════════════════════════════════════════

async function updateCashierStats(){
  if(currentUser) document.getElementById('stats-cashier-name').textContent=currentUser.name;
  let stats;
  try{ stats=await Api.statsOverview({}); }catch(_){ stats=null; }
  const totalRev = stats?Number(stats.summary.total_revenue):0;
  const cnt      = stats?Number(stats.summary.invoice_count):0;
  const avg      = cnt>0?Math.round(totalRev/cnt):0;
  document.getElementById('stats-revenue').textContent=fmt(totalRev);
  document.getElementById('stats-invoices').textContent=cnt;
  document.getElementById('stats-avg').textContent=cnt>0?fmt(avg):'0 đ';
  // Top items
  const topItems=(stats&&stats.topItems)||[];
  const topList=document.getElementById('stats-top-items');
  if(topItems.length===0){
    topList.innerHTML='<p class="text-sm text-on-surface-variant text-center py-4">Chưa có dữ liệu.</p>';return;
  }
  topList.innerHTML=topItems.slice(0,3).map((item,i)=>{
    const m=MENU_ITEMS.find(x=>x.name===item.name);
    const emoji=(m&&m.emoji)||'🍽';
    return `
    <div class="flex items-center gap-3 ${i<Math.min(topItems.length,3)-1?'border-b border-outline-variant pb-3':''}">
      <div class="w-8 h-8 rounded-full ${i===0?'bg-primary text-white':i===1?'bg-secondary text-white':'bg-surface-container text-on-surface'} flex items-center justify-center font-bold text-sm shrink-0">${i+1}</div>
      <div class="text-2xl">${emoji}</div>
      <div class="flex-1"><p class="font-semibold text-on-surface text-sm">${item.name}</p><p class="text-xs text-on-surface-variant">${fmt(Number(item.price))}</p></div>
      <span class="text-sm font-bold text-on-surface">${item.qty} phần</span>
    </div>`;
  }).join('');
}
