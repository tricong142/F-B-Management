// ═══════════════════════════════════════════════════════
//  RestoManager – POS Payment Module
//  (payment flow, keypad, receipt, print)
// ═══════════════════════════════════════════════════════

const PAY_METHOD_DEFS = [
  { key:'cash',     label:'Tiền mặt',     icon:'payments',         needsQR:false },
  { key:'transfer', label:'Chuyển khoản', icon:'qr_code_2',        needsQR:true  },
  { key:'card',     label:'Quẹt thẻ',     icon:'credit_card',      needsQR:false },
  { key:'vnpay',    label:'VietQR Pro',   icon:'qr_code_scanner',  needsQR:true  },
  { key:'banking',  label:'Banking',      icon:'account_balance',  needsQR:true  },
  { key:'momo',     label:'MoMo',         icon:'smartphone',       needsQR:false },
];

let currentPayState = {
  sub: 0, vat: 0, total: 0,
  paid: 0, change: 0,
  method: 'cash',
};
let currentInvoice = null;

function goPayment(){
  const tableOrders = orders.filter(o => o.tableId===currentTableId && o.status!=='paid');
  const allItems = {};
  tableOrders.forEach(o => o.items.forEach(i => {
    const k = i.name;
    if(!allItems[k]) allItems[k] = {...i, qty:0};
    allItems[k].qty += i.qty;
  }));
  const items = Object.values(allItems);
  const sub   = items.reduce((s,i)=>s + i.price*i.qty, 0);
  const vatRate = 8;
  const vat   = Math.round(sub * vatRate / 100);
  const total = sub + vat;

  currentPayState = { sub, vat, total, paid: total, change: 0, method: 'cash' };

  document.getElementById('pay-table-label').textContent = `Bàn ${currentTableId}`;
  document.getElementById('pay-inv-id').textContent = 'tạm tính';
  document.getElementById('pay-vat-rate').textContent = String(vatRate);
  document.getElementById('pay-sub').textContent   = fmt(sub);
  document.getElementById('pay-vat').textContent   = fmt(vat);
  document.getElementById('pay-total').textContent = fmt(total);
  document.getElementById('pay-items-mini').innerHTML = items.map(i => `
    <div class="flex justify-between text-xs">
      <span class="text-on-surface-variant">${i.emoji||'🍽'} ${i.name} ×${i.qty}</span>
      <span class="font-semibold text-on-surface">${fmt(i.price*i.qty)}</span>
    </div>`).join('') || '<div class="text-xs text-on-surface-variant">Không có món.</div>';

  renderPayMethods();
  renderPayKeypad();
  renderQuickAmounts();
  setPaidInput(total);
  selectPayMethod('cash');
  goPage('pg-cashier-payment');
}

function renderPayMethods(){
  const grid = document.getElementById('pay-methods-grid');
  grid.innerHTML = PAY_METHOD_DEFS.map(m => `
    <button onclick="selectPayMethod('${m.key}')"
            data-pay-method="${m.key}"
            class="pay-method-card flex flex-col items-center gap-1 p-3 rounded-xl border bg-white text-on-surface text-xs font-medium transition">
      <span class="material-symbols-outlined text-[22px] text-on-surface-variant">${m.icon}</span>
      <span>${m.label}</span>
    </button>`).join('');
}

function selectPayMethod(method, el){
  currentPayState.method = method;
  document.querySelectorAll('[data-pay-method]').forEach(b => {
    const on = b.dataset.payMethod === method;
    b.classList.toggle('border-primary', on);
    b.classList.toggle('bg-primary-container', on);
    b.classList.toggle('text-on-primary-container', on);
    b.classList.toggle('border-outline-variant', !on);
  });
  const def = PAY_METHOD_DEFS.find(x => x.key === method);
  document.getElementById('qr-display').classList.toggle('hidden', !(def && def.needsQR));
}

function renderPayKeypad(){
  const kp = document.getElementById('pay-keypad');
  const labels = { back:'⌫', clear:'C' };
  const layout = [
    ['7','8','9','back'],
    ['4','5','6','clear'],
    ['1','2','3','000'],
    ['0',null,null,null],
  ];
  let html = '';
  layout.forEach(row => {
    row.forEach((k, idx) => {
      if (k === null) return;
      const wide = (k === '0') ? 'col-span-4' : '';
      const util = (k === 'back' || k === 'clear');
      html += `<button onclick="keypadPress('${k}')"
        class="${wide} h-12 rounded-xl ${util ? 'bg-surface-container-highest text-on-surface' : 'bg-surface-container-low text-on-surface'} font-semibold text-base active:scale-95 transition">
        ${labels[k] || k}
      </button>`;
    });
  });
  kp.innerHTML = html;
}

function renderQuickAmounts(){
  const total = currentPayState.total;
  const opts = [total, total + 5000, total + 10000, total + 50000, total + 100000, total + 200000];
  document.getElementById('pay-quick-amounts').innerHTML = opts.map(v => `
    <button onclick="setPaidInput(${v})"
            class="h-10 px-2 rounded-xl bg-surface-container-low border border-outline-variant text-xs font-semibold text-on-surface active:scale-95 transition">
      ${fmt(v)}
    </button>`).join('');
}

function keypadPress(k){
  const inp = document.getElementById('pay-paid-input');
  let v = String(inp.value || '0');
  if (k === 'back') v = v.length <= 1 ? '0' : v.slice(0, -1);
  else if (k === 'clear') v = '0';
  else if (k === '000') v = (v === '0' ? '0' : v + '000');
  else v = (v === '0' ? k : v + k);
  v = v.replace(/^0+(\d)/, '$1');
  if (v === '') v = '0';
  setPaidInput(Number(v));
}

function setPaidInput(num){
  const n = Math.max(0, Math.floor(Number(num) || 0));
  document.getElementById('pay-paid-input').value = n;
  currentPayState.paid = n;
  currentPayState.change = Math.max(0, n - currentPayState.total);
  document.getElementById('pay-change').textContent = fmt(currentPayState.change);
}

// Khi user gõ tay vào input
document.addEventListener('DOMContentLoaded', () => {
  const inp = document.getElementById('pay-paid-input');
  if (inp) {
    inp.addEventListener('input', e => {
      const cleaned = String(e.target.value).replace(/[^0-9]/g, '') || '0';
      setPaidInput(Number(cleaned));
    });
  }
});

async function confirmPayment(){
  if(!currentOpenOrder || !currentOpenOrder.id){
    toast('Bàn này không có order đang mở','warning'); return;
  }
  if (currentPayState.paid < currentPayState.total) {
    toast('Khách trả chưa đủ', 'warning'); return;
  }
  try{
    const inv = await Api.checkout(currentOpenOrder.id, {
      cashier_name:   currentUser?.name || 'Thu ngân',
      payment_method: currentPayState.method,
      vat_rate:       8,
      discount:       0,
      paid_amount:    currentPayState.paid,
    });
    currentInvoice = inv;
    showReceipt(inv);
    await loadTablesFromApi();
    await loadOrdersFromApi({status:'pending,serving'});
    await loadPaidOrdersFromApi();
    updateCashierStats();
  }catch(err){
    toast(err.message||'Thanh toán thất bại','error');
  }
}

// ─── Receipt modal ────────────────────────────────────────
const PAY_LABELS = { cash:'Tiền mặt', card:'Thẻ', transfer:'Chuyển khoản',
  online:'Bán online', grab:'Grab', vnpay:'VietQR Pro', banking:'Banking',
  momo:'MoMo', zalopay:'ZaloPay' };

function showReceipt(inv){
  document.getElementById('rc-code').textContent     = inv.code || '';
  document.getElementById('rc-table').textContent    = inv.table_code || '';
  document.getElementById('rc-cashier').textContent  = inv.cashier_name || '';
  document.getElementById('rc-checkin').textContent  = inv.check_in_time  ? new Date(inv.check_in_time).toLocaleString('vi-VN')  : '–';
  document.getElementById('rc-checkout').textContent = inv.check_out_time ? new Date(inv.check_out_time).toLocaleString('vi-VN') : '–';
  document.getElementById('rc-method').textContent   = PAY_LABELS[inv.payment_method] || inv.payment_method || '';
  document.getElementById('rc-items').innerHTML = (inv.items || []).map(i => `
    <tr class="border-t border-outline-variant/40">
      <td class="py-1">${i.item_name}</td>
      <td class="py-1 text-right">${i.quantity}</td>
      <td class="py-1 text-right">${fmt(i.price)}</td>
      <td class="py-1 text-right font-semibold">${fmt(i.total_price)}</td>
    </tr>`).join('');
  document.getElementById('rc-sub').textContent    = fmt(Number(inv.total_amount));
  document.getElementById('rc-vat').textContent    = fmt(Number(inv.vat_amount));
  document.getElementById('rc-total').textContent  = fmt(Number(inv.final_amount));
  document.getElementById('rc-paid').textContent   = fmt(Number(inv.paid_amount  ?? inv.final_amount));
  document.getElementById('rc-change').textContent = fmt(Number(inv.change_amount ?? 0));
  const dlg = document.getElementById('receipt-dlg');
  dlg.classList.remove('hidden');
  dlg.classList.add('flex');
}

async function closeReceipt(){
  document.getElementById('receipt-dlg').classList.add('hidden');
  document.getElementById('receipt-dlg').classList.remove('flex');
  await loadTablesFromApi();
  refreshCashierTables();
  renderCashierOrders();
  goPage('pg-cashier-tables');
}

function printReceipt(){
  const inv = currentInvoice; if(!inv) return;
  const w = window.open('', '_blank', 'width=420,height=720');
  if(!w){ toast('Trình duyệt đã chặn cửa sổ in','warning'); return; }
  const rows = (inv.items || []).map(i => `
    <tr><td>${i.item_name}</td><td class="r">${i.quantity}</td>
        <td class="r">${fmt(Number(i.price))}</td>
        <td class="r">${fmt(Number(i.total_price))}</td></tr>`).join('');
  const html = `<!doctype html><html><head><meta charset="utf-8"/>
<title>Hoá đơn ${inv.code||''}</title>
<style>
  body{font-family:Arial,sans-serif;padding:20px;color:#111;font-size:13px;}
  h1{font-size:18px;margin:0 0 8px;text-align:center;}
  .meta p{margin:2px 0;font-size:12px;}
  table{width:100%;border-collapse:collapse;margin-top:12px;}
  th,td{border-bottom:1px dashed #ccc;padding:6px 4px;font-size:12px;text-align:left;}
  th{background:#f5f5f5;}
  .r{text-align:right;}
  .summary{margin-top:12px;font-size:13px;}
  .summary div{display:flex;justify-content:space-between;margin:3px 0;}
  .summary .total{font-weight:bold;font-size:15px;border-top:1px solid #000;padding-top:6px;margin-top:6px;}
  .center{text-align:center;}
  .footer{margin-top:18px;text-align:center;font-size:11px;color:#666;}
</style></head><body>
  <h1>HOÁ ĐƠN THANH TOÁN</h1>
  <div class="meta">
    <p><b>Mã HĐ:</b> ${inv.code||''}</p>
    <p><b>Bàn:</b> ${inv.table_code||''}</p>
    <p><b>Thu ngân:</b> ${inv.cashier_name||''}</p>
    <p><b>Giờ vào:</b> ${inv.check_in_time ? new Date(inv.check_in_time).toLocaleString('vi-VN'):'–'}</p>
    <p><b>Giờ ra:</b> ${inv.check_out_time? new Date(inv.check_out_time).toLocaleString('vi-VN'):'–'}</p>
    <p><b>PT thanh toán:</b> ${PAY_LABELS[inv.payment_method] || inv.payment_method || ''}</p>
  </div>
  <table>
    <thead><tr><th>Món</th><th class="r">SL</th><th class="r">Đơn giá</th><th class="r">TT</th></tr></thead>
    <tbody>${rows}</tbody>
  </table>
  <div class="summary">
    <div><span>Tạm tính</span><span>${fmt(Number(inv.total_amount))}</span></div>
    <div><span>VAT (${inv.vat_rate}%)</span><span>${fmt(Number(inv.vat_amount))}</span></div>
    <div class="total"><span>Tổng cộng</span><span>${fmt(Number(inv.final_amount))}</span></div>
    <div><span>Khách trả</span><span>${fmt(Number(inv.paid_amount ?? inv.final_amount))}</span></div>
    <div><span>Tiền thừa</span><span>${fmt(Number(inv.change_amount ?? 0))}</span></div>
  </div>
  <div class="footer">Cảm ơn quý khách. Hẹn gặp lại!</div>
  <scr` + `ipt>window.onload=()=>setTimeout(()=>window.print(),250);</scr` + `ipt>
</body></html>`;
  w.document.open(); w.document.write(html); w.document.close(); w.focus();
}

async function afterPayment(){
  closeDlg('success-dlg');
  await loadTablesFromApi();
  await loadOrdersFromApi({status:'pending,serving'});
  refreshCashierTables();
  renderCashierOrders();
  goPage('pg-cashier-tables');
}
