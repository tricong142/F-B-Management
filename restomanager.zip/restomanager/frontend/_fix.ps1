# The file was double-encoded: original UTF-8 bytes were read as Windows-1252 by PowerShell,
# then written back as UTF-8, producing mojibake.
# To fix: read current UTF-8, get bytes, interpret those bytes as Windows-1252 to get the
# original UTF-8 byte sequence, then write those raw bytes back.

$file = "d:\Downloads\PT_UDPMC\restaurant-management-invoice-payment\demo.F.B.app.and.web\restomanager\frontend\pos.html"

# Read current file as raw bytes
$rawBytes = [System.IO.File]::ReadAllBytes($file)

# Decode as UTF-8 to get the (mojibake) string
$utf8 = [System.Text.Encoding]::UTF8
$text = $utf8.GetString($rawBytes)

# Encode as Windows-1252 to recover original UTF-8 bytes
$cp1252 = [System.Text.Encoding]::GetEncoding(1252)
$originalBytes = $cp1252.GetBytes($text)

# Write the recovered bytes directly
[System.IO.File]::WriteAllBytes($file, $originalBytes)

# Verify
$verifyText = [System.IO.File]::ReadAllText($file, $utf8)
$lines = $verifyText -split "`n"
Write-Host "Line 6: $($lines[5].Trim())"
Write-Host "Total lines: $($lines.Length)"
Write-Host "File size: $((Get-Item $file).Length) bytes"
