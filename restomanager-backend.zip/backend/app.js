// =============================================================================
//  app.js  — Cấu hình Express: middleware, routes, error handler
// =============================================================================
const express = require('express');
const cors    = require('cors');
const { ok }  = require('./src/utils/response');
const { notFoundHandler, globalErrorHandler } = require('./src/middleware/errorHandler');

const authRoutes    = require('./src/routes/authRoutes');
const userRoutes    = require('./src/routes/userRoutes');
const menuRoutes    = require('./src/routes/menuRoutes');
const tableRoutes   = require('./src/routes/tableRoutes');
const orderRoutes   = require('./src/routes/orderRoutes');
const invoiceRoutes = require('./src/routes/invoiceRoutes');
const fileRoutes    = require('./src/routes/fileRoutes');
const statRoutes    = require('./src/routes/statRoutes');
const logRoutes     = require('./src/routes/logRoutes');

const app = express();

// ─── CORS ─────────────────────────────────────────────────────────────────────
const ALLOWED_ORIGINS = process.env.CORS_ORIGINS
  ? process.env.CORS_ORIGINS.split(',').map(o => o.trim())
  : true; // true = allow all (dev mode)

app.use(cors({
  origin:      ALLOWED_ORIGINS,
  credentials: true,
  methods:     ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

// ─── CORE MIDDLEWARE ──────────────────────────────────────────────────────────
app.disable('x-powered-by');
app.set('trust proxy', true);                         // lấy IP đúng sau proxy/nginx
app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: true, limit: '5mb' }));

// Request logger (không log body để tránh lộ password)
app.use((req, _res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.originalUrl} — ${req.ip}`);
  next();
});

// ─── HEALTH CHECK ─────────────────────────────────────────────────────────────
app.get('/api/health', (_req, res) =>
  ok(res, {
    status:    'ok',
    service:   'RestoManager API',
    version:   '2.1.0',
    timestamp: new Date().toISOString(),
  })
);

// ─── ROUTES ───────────────────────────────────────────────────────────────────
app.use('/api/auth',     authRoutes);       // đăng nhập / refresh / logout
app.use('/api/users',    userRoutes);       // quản lý nhân viên
app.use('/api/menu',     menuRoutes);       // thực đơn + danh mục
app.use('/api/tables',   tableRoutes);      // quản lý bàn (+ chuyển bàn)
app.use('/api/orders',   orderRoutes);      // đơn hàng
app.use('/api/invoices', invoiceRoutes);    // hoá đơn
app.use('/api/files',    fileRoutes);       // upload file → MinIO
app.use('/api/stats',    statRoutes);       // thống kê doanh thu
app.use('/api/logs',     logRoutes);        // activity log

// ─── ERROR HANDLERS ───────────────────────────────────────────────────────────
app.use(notFoundHandler);
app.use(globalErrorHandler);

module.exports = app;
