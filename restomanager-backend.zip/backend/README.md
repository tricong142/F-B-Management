# RestoManager Backend — v2.1.0

Hệ thống Quản lý Nhà hàng — RESTful API xây dựng trên **Express.js + PostgreSQL + MinIO**.

---

## Cấu trúc thư mục

```
backend/
├── server.js                    ← Bootstrap + graceful shutdown
├── app.js                       ← Express: CORS, middleware, routes
├── package.json
├── .env.example                 ← Copy thành .env và điền giá trị
├── Dockerfile
│
├── migrations/
│   ├── 001_init.sql             ← Schema chính: 9 bảng + seed data
│   ├── 002_dedupe_menu.sql      ← Xử lý trùng menu + UNIQUE constraint
│   ├── 003_invoice_payment_fields.sql  ← paid_amount, change_amount
│   ├── 004_refresh_tokens.sql   ← Bảng refresh_tokens (JWT refresh flow)
│   └── 005_table_management.sql ← table_zones, table_move_logs, notes
│
└── src/
    ├── database/
    │   ├── db.js                ← pg Pool, query/queryOne/transaction helper
    │   └── seed.js              ← Seed 3 user mặc định (admin/cashier/waiter)
    │
    ├── storage/
    │   └── minio.js             ← MinIO client, uploadBuffer, deleteObject
    │
    ├── utils/
    │   └── response.js          ← ok/created/paged/ApiError/asyncHandler
    │
    ├── middleware/
    │   ├── auth.js              ← JWT sign/verify, requireAuth, requireRole
    │   │                          + refresh token helpers
    │   ├── errorHandler.js      ← Global error handler (ApiError + PG errors)
    │   └── validate.js          ← validateBody/Query/Params middleware
    │
    ├── models/
    │   ├── User.js, Table.js, Order.js
    │   ├── MenuItem.js, Invoice.js, Log.js
    │
    ├── controllers/
    │   ├── authController.js    ← login, refresh, logout, me, changePassword
    │   ├── userController.js    ← CRUD nhân viên
    │   ├── menuController.js    ← CRUD thực đơn + upload ảnh
    │   ├── tableController.js   ← CRUD bàn + moveTable + zones + moveLogs
    │   ├── orderController.js   ← Tạo/sửa/hủy order + checkout
    │   ├── invoiceController.js ← Xem hoá đơn
    │   ├── statController.js    ← Thống kê doanh thu (overview/daily/monthly)
    │   ├── logController.js     ← Activity log
    │   └── fileController.js    ← Upload file chung
    │
    └── routes/
        ├── authRoutes.js, userRoutes.js, menuRoutes.js
        ├── tableRoutes.js, orderRoutes.js, invoiceRoutes.js
        ├── statRoutes.js, logRoutes.js, fileRoutes.js
```

---

## API Endpoints

### Auth — `/api/auth`
| Method | Path | Mô tả | Auth |
|--------|------|-------|------|
| POST | `/login` | Đăng nhập → access_token + refresh_token | ✗ |
| POST | `/refresh` | Làm mới access_token | ✗ |
| POST | `/logout` | Đăng xuất (revoke refresh token) | ✓ |
| GET  | `/me` | Thông tin user hiện tại | ✓ |
| PUT  | `/change-password` | Đổi mật khẩu | ✓ |

### Tables — `/api/tables`
| Method | Path | Mô tả | Role |
|--------|------|-------|------|
| GET  | `/` | Danh sách bàn (`?with_status=true`) | auth |
| POST | `/` | Tạo bàn | admin |
| GET  | `/zones` | Danh sách zone | auth |
| GET  | `/move-logs` | Lịch sử chuyển bàn | admin |
| POST | `/move` | **Chuyển bàn** | auth |
| PUT  | `/:id` | Cập nhật bàn | admin |
| DELETE | `/:id` | Xoá bàn | admin |

### Orders — `/api/orders`
| Method | Path | Role |
|--------|------|------|
| POST | `/` | waiter, admin |
| GET  | `/` | auth |
| GET  | `/by-table/:tableId` | auth |
| GET  | `/:id` | auth |
| PUT  | `/:id/status` | waiter, cashier, admin |
| POST | `/:id/items` | waiter, cashier, admin |
| PUT  | `/:id/items/:itemId` | waiter, cashier, admin |
| DELETE | `/:id/items/:itemId` | waiter, cashier, admin |
| POST | `/:id/checkout` | cashier, admin |
| DELETE | `/:id` | waiter, cashier, admin |

### Stats — `/api/stats` (cashier + admin)
| GET `/overview` | GET `/daily?days=14` | GET `/monthly?year=2025` |

---

## Chạy local

```bash
# 1. Copy env
cp .env.example .env

# 2. Cài packages
npm install

# 3. Chạy PostgreSQL + MinIO (Docker)
docker compose up -d postgres minio

# 4. Start server (tự chạy migration + seed)
npm run dev
```

### Tài khoản mặc định (seed)
| Username | Password | Role |
|----------|----------|------|
| admin | 123 | admin |
| cashier | 123 | cashier |
| waiter | 123 | waiter |

---

## Envelope Response

```json
// Thành công
{ "success": true,  "data": {...}, "message": "...", "meta": {} }

// Lỗi
{ "success": false, "message": "...", "error": { "code": "BAD_REQUEST", "details": [] } }
```

## Mã lỗi phổ biến
| Code | HTTP | Ý nghĩa |
|------|------|---------|
| `BAD_REQUEST` | 400 | Tham số sai |
| `UNAUTHORIZED` | 401 | Chưa xác thực / token hết hạn |
| `FORBIDDEN` | 403 | Không đủ quyền |
| `NOT_FOUND` | 404 | Tài nguyên không tồn tại |
| `CONFLICT` | 409 | Vi phạm điều kiện nghiệp vụ |
| `VALIDATION_ERROR` | 422 | Dữ liệu không hợp lệ |
| `INTERNAL_ERROR` | 500 | Lỗi server |
