// =============================================================================
//  auth.js  — JWT middleware + refresh token helpers
// =============================================================================
const jwt    = require('jsonwebtoken');
const crypto = require('crypto');
const db     = require('../database/db');
const { ApiError } = require('../utils/response');

const JWT_SECRET         = process.env.JWT_SECRET         || 'restomanager-dev-secret-change-me';
const JWT_EXPIRES        = process.env.JWT_EXPIRES        || '15m';   // Access token ngắn
const JWT_REFRESH_EXPIRES= process.env.JWT_REFRESH_EXPIRES|| '7d';    // Refresh token dài

// ─── Token helpers ────────────────────────────────────────────────────────────

/** Tạo access token (ngắn hạn). */
function signToken(payload) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES });
}

/** Tạo refresh token (ngẫu nhiên 64 bytes hex, không phải JWT). */
function generateRefreshToken() {
  return crypto.randomBytes(64).toString('hex');
}

/** Hash refresh token trước khi lưu DB (tránh lộ raw token nếu DB bị dump). */
function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

/** Verify access token, throw nếu hết hạn / sai. */
function verifyToken(token) {
  return jwt.verify(token, JWT_SECRET);
}

// ─── Middleware ───────────────────────────────────────────────────────────────

/** Yêu cầu Authorization: Bearer <access_token>. */
function requireAuth(req, _res, next) {
  const header = req.headers.authorization || '';
  const token  = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return next(ApiError.unauthorized('Thiếu token xác thực'));
  try {
    req.user = verifyToken(token);
    return next();
  } catch (err) {
    return next(err); // globalErrorHandler map JWT errors → 401
  }
}

/** Yêu cầu user có 1 trong các vai trò chỉ định. */
function requireRole(...roles) {
  return (req, _res, next) => {
    if (!req.user) return next(ApiError.unauthorized('Chưa xác thực'));
    if (!roles.includes(req.user.role))
      return next(ApiError.forbidden(`Yêu cầu vai trò: ${roles.join(', ')}`));
    next();
  };
}

// ─── Refresh token DB helpers ─────────────────────────────────────────────────

/** Lưu refresh token vào DB. Trả về raw token (gửi về client). */
async function saveRefreshToken(userId, { ip, userAgent } = {}) {
  const raw  = generateRefreshToken();
  const hash = hashToken(raw);
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 ngày

  await db.query(
    `INSERT INTO refresh_tokens (user_id, token_hash, ip, user_agent, expires_at)
     VALUES ($1, $2, $3, $4, $5)`,
    [userId, hash, ip || null, userAgent || null, expiresAt]
  );
  return raw;
}

/**
 * Xác minh + rotate refresh token.
 * - Tìm token trong DB theo hash.
 * - Nếu hợp lệ: revoke cũ, tạo token mới (rotation).
 * - Trả về { user_id } hoặc throw.
 */
async function rotateRefreshToken(rawToken, { ip, userAgent } = {}) {
  const hash = hashToken(rawToken);
  const row  = await db.queryOne(
    `SELECT * FROM refresh_tokens WHERE token_hash = $1`, [hash]
  );

  if (!row)               throw ApiError.unauthorized('Refresh token không hợp lệ');
  if (row.revoked_at)     throw ApiError.unauthorized('Refresh token đã bị thu hồi');
  if (new Date() > new Date(row.expires_at))
                          throw ApiError.unauthorized('Refresh token đã hết hạn');

  // Revoke token cũ
  await db.query(
    `UPDATE refresh_tokens SET revoked_at = NOW() WHERE id = $1`, [row.id]
  );

  // Cấp token mới
  const newRaw = await saveRefreshToken(row.user_id, { ip, userAgent });
  return { user_id: row.user_id, refresh_token: newRaw };
}

/** Thu hồi 1 refresh token (logout). */
async function revokeRefreshToken(rawToken) {
  const hash = hashToken(rawToken);
  await db.query(
    `UPDATE refresh_tokens SET revoked_at = NOW()
     WHERE token_hash = $1 AND revoked_at IS NULL`,
    [hash]
  );
}

/** Thu hồi TẤT CẢ refresh token của 1 user (logout all devices). */
async function revokeAllRefreshTokens(userId) {
  await db.query(
    `UPDATE refresh_tokens SET revoked_at = NOW()
     WHERE user_id = $1 AND revoked_at IS NULL`,
    [userId]
  );
}

module.exports = {
  signToken, verifyToken, generateRefreshToken, hashToken,
  requireAuth, requireRole,
  saveRefreshToken, rotateRefreshToken, revokeRefreshToken, revokeAllRefreshTokens,
  JWT_SECRET,
};
