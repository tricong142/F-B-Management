// =============================================================================
//  tableRoutes.js  — /api/tables
//
//  Endpoint map:
//   GET    /api/tables            → list (auth)
//   POST   /api/tables            → create (admin)
//   GET    /api/tables/zones      → listZones (auth)       ← trước /:id
//   GET    /api/tables/move-logs  → getMoveLog (admin)     ← trước /:id
//   POST   /api/tables/move       → moveTable (auth)       ← trước /:id
//   PUT    /api/tables/:id        → update (admin)
//   DELETE /api/tables/:id        → remove (admin)
//
//  Chú ý: Các route có path cố định (zones, move-logs, move) PHẢI khai báo
//  TRƯỚC /:id để Express không nhầm "zones" là một UUID.
// =============================================================================

const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/tableController');
const { requireAuth, requireRole } = require('../middleware/auth');
const { validateBody }             = require('../middleware/validate');

// ── GET /api/tables ──────────────────────────────────────────────────────────
// Query params: ?with_status=true&zone=t1&page=1&limit=50
router.get('/', requireAuth, ctrl.list);

// ── POST /api/tables ─────────────────────────────────────────────────────────
// Tạo bàn mới — chỉ admin
router.post(
  '/',
  requireAuth, requireRole('admin'),
  validateBody({
    code:     { required: true, type: 'string',  minLength: 1 },
    zone:     { required: true, type: 'string',  minLength: 1 },
    capacity: { required: true, type: 'integer', min: 1 },
  }),
  ctrl.create,
);

// ── GET /api/tables/zones ────────────────────────────────────────────────────
// Danh sách zone hợp lệ (cho dropdown trên frontend)
router.get('/zones', requireAuth, ctrl.listZones);

// ── GET /api/tables/move-logs ────────────────────────────────────────────────
// Lịch sử chuyển bàn — chỉ admin
// Query: ?from=ISO&to=ISO&table_code=T1-01&page=1&limit=50
router.get('/move-logs', requireAuth, requireRole('admin'), ctrl.getMoveLog);

// ── POST /api/tables/move ────────────────────────────────────────────────────
// Chuyển bàn (waiter + cashier + admin)
// Body: { from_table_id: UUID, to_table_id: UUID, reason?: string }
router.post(
  '/move',
  requireAuth,
  validateBody({
    from_table_id: { required: true, type: 'string', minLength: 1 },
    to_table_id:   { required: true, type: 'string', minLength: 1 },
  }),
  ctrl.moveTable,
);

// ── PUT /api/tables/:id ───────────────────────────────────────────────────────
// Cập nhật thông tin bàn — chỉ admin
// Body (tất cả tuỳ chọn): { code, zone, capacity, is_active, notes }
router.put('/:id', requireAuth, requireRole('admin'), ctrl.update);

// ── DELETE /api/tables/:id ───────────────────────────────────────────────────
// Xoá bàn — chỉ admin (sẽ từ chối nếu bàn đang có khách)
router.delete('/:id', requireAuth, requireRole('admin'), ctrl.remove);

module.exports = router;
