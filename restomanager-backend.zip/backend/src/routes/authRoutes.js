// =============================================================================
//  authRoutes.js  — /api/auth
// =============================================================================
const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/authController');
const { requireAuth }  = require('../middleware/auth');
const { validateBody } = require('../middleware/validate');

// POST /api/auth/login
router.post('/login',
  validateBody({
    username: { required: true, type: 'string', minLength: 1 },
    password: { required: true, type: 'string', minLength: 1 },
  }),
  ctrl.login
);

// POST /api/auth/refresh  — lấy access_token mới từ refresh_token
router.post('/refresh',
  validateBody({ refresh_token: { required: true, type: 'string', minLength: 1 } }),
  ctrl.refresh
);

// POST /api/auth/logout
router.post('/logout', requireAuth, ctrl.logout);

// GET /api/auth/me
router.get('/me', requireAuth, ctrl.me);

// PUT /api/auth/change-password
router.put('/change-password',
  requireAuth,
  validateBody({
    current_password: { required: true, type: 'string', minLength: 1 },
    new_password:     { required: true, type: 'string', minLength: 4 },
  }),
  ctrl.changePassword
);

module.exports = router;
