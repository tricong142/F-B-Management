// =============================================================================
//  statRoutes.js  — /api/stats
// =============================================================================
const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/statController');
const { requireAuth, requireRole } = require('../middleware/auth');

// Số liệu doanh thu — chỉ cashier + admin
router.use(requireAuth, requireRole('cashier', 'admin'));

router.get('/overview', ctrl.overview);   // hôm nay / khoảng tuỳ chọn
router.get('/daily',    ctrl.daily);      // N ngày gần nhất
router.get('/monthly',  ctrl.monthly);    // theo tháng trong năm

module.exports = router;
