// =============================================================================
//  authController.js  — Đăng nhập, Đăng xuất, Refresh Token, /me
// =============================================================================
const UserModel  = require('../models/User');
const LogModel   = require('../models/Log');
const {
  signToken,
  saveRefreshToken, rotateRefreshToken,
  revokeRefreshToken, revokeAllRefreshTokens,
} = require('../middleware/auth');
const { ok, asyncHandler, ApiError } = require('../utils/response');

// ─── POST /api/auth/login ─────────────────────────────────────────────────────
exports.login = asyncHandler(async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password)
    throw ApiError.validation('Vui lòng nhập tên đăng nhập và mật khẩu');

  const user = await UserModel.findByUsername(String(username).trim());
  if (!user || !user.is_active)
    throw ApiError.unauthorized('Tên đăng nhập hoặc mật khẩu không đúng');

  const verified = await UserModel.verifyPassword(user, password);
  if (!verified)
    throw ApiError.unauthorized('Tên đăng nhập hoặc mật khẩu không đúng');

  // Cấp access token + refresh token
  const payload = { id: user.id, username: user.username, role: user.role, full_name: user.full_name };
  const accessToken  = signToken(payload);
  const refreshToken = await saveRefreshToken(user.id, {
    ip:        req.ip,
    userAgent: req.headers['user-agent'],
  });

  LogModel.write({
    user_id: user.id, user_name: user.full_name,
    action: 'LOGIN', entity: 'USER', entity_id: user.id, ip: req.ip,
  }).catch(() => {});

  return ok(res, {
    access_token:  accessToken,
    refresh_token: refreshToken,
    user: UserModel.publicView(user),
  }, { message: 'Đăng nhập thành công' });
});

// ─── POST /api/auth/refresh ───────────────────────────────────────────────────
// Body: { refresh_token }
// Trả về access_token mới + refresh_token mới (rotation)
exports.refresh = asyncHandler(async (req, res) => {
  const { refresh_token } = req.body || {};
  if (!refresh_token)
    throw ApiError.validation('Thiếu refresh_token');

  const { user_id, refresh_token: newRefresh } = await rotateRefreshToken(refresh_token, {
    ip:        req.ip,
    userAgent: req.headers['user-agent'],
  });

  const user = await UserModel.findById(user_id);
  if (!user || !user.is_active)
    throw ApiError.unauthorized('Tài khoản không tồn tại hoặc đã bị khoá');

  const payload     = { id: user.id, username: user.username, role: user.role, full_name: user.full_name };
  const accessToken = signToken(payload);

  return ok(res, {
    access_token:  accessToken,
    refresh_token: newRefresh,
  }, { message: 'Làm mới token thành công' });
});

// ─── POST /api/auth/logout ────────────────────────────────────────────────────
// Body tuỳ chọn: { refresh_token, all?: true }
// all=true → revoke tất cả thiết bị của user
exports.logout = asyncHandler(async (req, res) => {
  const { refresh_token, all } = req.body || {};

  if (all && req.user?.id) {
    await revokeAllRefreshTokens(req.user.id);
  } else if (refresh_token) {
    await revokeRefreshToken(refresh_token);
  }

  if (req.user) {
    LogModel.write({
      user_id: req.user.id, user_name: req.user.full_name,
      action: 'LOGOUT', entity: 'USER', entity_id: req.user.id, ip: req.ip,
    }).catch(() => {});
  }

  return ok(res, null, { message: 'Đã đăng xuất' });
});

// ─── GET /api/auth/me ─────────────────────────────────────────────────────────
exports.me = asyncHandler(async (req, res) => {
  const user = await UserModel.findById(req.user.id);
  if (!user) throw ApiError.notFound('User không tồn tại');
  return ok(res, UserModel.publicView(user));
});

// ─── PUT /api/auth/change-password ───────────────────────────────────────────
// Body: { current_password, new_password }
exports.changePassword = asyncHandler(async (req, res) => {
  const { current_password, new_password } = req.body || {};
  if (!current_password || !new_password)
    throw ApiError.validation('Thiếu current_password hoặc new_password');
  if (String(new_password).length < 4)
    throw ApiError.validation('Mật khẩu mới phải có ít nhất 4 ký tự');

  const user = await UserModel.findById(req.user.id);
  const ok2  = await UserModel.verifyPassword(user, current_password);
  if (!ok2) throw ApiError.unauthorized('Mật khẩu hiện tại không đúng');

  await UserModel.resetPassword(req.user.id, new_password);

  // Revoke tất cả refresh token cũ sau khi đổi mật khẩu
  await revokeAllRefreshTokens(req.user.id);

  LogModel.write({
    user_id: req.user.id, user_name: req.user.full_name,
    action: 'CHANGE_PASSWORD', entity: 'USER', entity_id: req.user.id,
  }).catch(() => {});

  return ok(res, null, { message: 'Đổi mật khẩu thành công. Vui lòng đăng nhập lại.' });
});
