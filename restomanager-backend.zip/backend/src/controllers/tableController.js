// =============================================================================
//  tableController.js  — Quản lý bàn: CRUD + Chuyển bàn + Zone
//  Đầy đủ chức năng:
//    list         GET  /api/tables
//    create       POST /api/tables
//    update       PUT  /api/tables/:id
//    remove       DEL  /api/tables/:id
//    moveTable    POST /api/tables/move
//    listZones    GET  /api/tables/zones
//    getMoveLog   GET  /api/tables/move-logs
// =============================================================================

const TableModel = require('../models/Table');
const LogModel   = require('../models/Log');
const db         = require('../database/db');
const {
  ok, created, paged, noContent,
  paginateArray, asyncHandler, ApiError,
} = require('../utils/response');

// ─── Helpers ─────────────────────────────────────────────────────────────────

/** Lấy danh sách zone hợp lệ từ DB (cache ngắn 60s để tránh query lặp). */
let _zoneCache = null;
let _zoneCacheAt = 0;
async function getValidZones() {
  if (_zoneCache && Date.now() - _zoneCacheAt < 60_000) return _zoneCache;
  const rows = await db.query(
    `SELECT code FROM table_zones WHERE is_active = TRUE ORDER BY sort_order`
  );
  _zoneCache = rows.map(r => r.code);
  _zoneCacheAt = Date.now();
  return _zoneCache;
}

// =============================================================================
//  1. Danh sách bàn
//  GET /api/tables?zone=t1&with_status=true&page=1&limit=50
// =============================================================================
exports.list = asyncHandler(async (req, res) => {
  const { zone, with_status, page, limit } = req.query;
  let tables;

  if (with_status === 'true') {
    // Kèm trạng thái realtime: tính từ open orders
    tables = await TableModel.findAllWithStatus(zone);
    tables = tables.map(t => {
      // Chuyển order_status sang nhãn giao diện thân thiện
      let status = 'available';   // không có khách
      if (t.order_status === 'pending') status = 'occupied';   // đã gọi món
      if (t.order_status === 'serving') status = 'serving';    // đang phục vụ
      const mins = t.check_in_time
        ? Math.max(0, Math.round((Date.now() - new Date(t.check_in_time).getTime()) / 60_000))
        : 0;
      return { ...t, status, mins };
    });
  } else {
    tables = await TableModel.findAll();
  }

  const r = paginateArray(tables, { page, limit });
  return paged(res, { ...r, message: `Danh sách bàn (${r.total})` });
});

// =============================================================================
//  2. Tạo bàn mới (admin)
//  POST /api/tables
//  Body: { code, zone, capacity, notes? }
// =============================================================================
exports.create = asyncHandler(async (req, res) => {
  const { code, zone, capacity, notes } = req.body || {};
  const validZones = await getValidZones();
  const errs = [];

  if (!code || String(code).trim() === '')
    errs.push('code: bắt buộc');
  if (!zone || !validZones.includes(zone))
    errs.push(`zone: phải thuộc {${validZones.join('|')}}`);
  if (!capacity || isNaN(Number(capacity)) || Number(capacity) < 1)
    errs.push('capacity: phải là số nguyên dương');
  if (errs.length) throw ApiError.validation('Dữ liệu không hợp lệ', errs);

  const t = await TableModel.create({
    code:     String(code).trim().toUpperCase(),
    zone,
    capacity: parseInt(capacity),
    notes:    notes || null,
  });

  LogModel.write({
    user_id: req.user?.id, user_name: req.user?.full_name,
    action: 'CREATE_TABLE', entity: 'TABLE', entity_id: t.id,
    details: { code: t.code, zone, capacity: t.capacity },
  }).catch(() => {});

  return created(res, t, 'Tạo bàn thành công');
});

// =============================================================================
//  3. Cập nhật bàn (admin)
//  PUT /api/tables/:id
//  Body (tuỳ chọn): { code, zone, capacity, is_active, notes }
// =============================================================================
exports.update = asyncHandler(async (req, res) => {
  if (req.body?.zone) {
    const validZones = await getValidZones();
    if (!validZones.includes(req.body.zone))
      throw ApiError.validation('Dữ liệu không hợp lệ', [`zone: phải thuộc {${validZones.join('|')}}`]);
  }

  const t = await TableModel.update(req.params.id, req.body || {});
  if (!t) throw ApiError.notFound('Bàn không tồn tại');

  LogModel.write({
    user_id: req.user?.id, user_name: req.user?.full_name,
    action: 'UPDATE_TABLE', entity: 'TABLE', entity_id: t.id,
    details: req.body,
  }).catch(() => {});

  return ok(res, t, { message: 'Cập nhật bàn thành công' });
});

// =============================================================================
//  4. Xoá bàn (admin)
//  DELETE /api/tables/:id
// =============================================================================
exports.remove = asyncHandler(async (req, res) => {
  // Không cho xoá bàn đang có order mở
  const openOrder = await db.queryOne(
    `SELECT id FROM orders WHERE table_id = $1 AND status IN ('pending','serving') LIMIT 1`,
    [req.params.id]
  );
  if (openOrder)
    throw ApiError.conflict('Không thể xoá bàn đang có khách. Vui lòng đóng order trước.');

  const r = await TableModel.remove(req.params.id);
  if (!r) throw ApiError.notFound('Bàn không tồn tại');

  LogModel.write({
    user_id: req.user?.id, user_name: req.user?.full_name,
    action: 'DELETE_TABLE', entity: 'TABLE', entity_id: req.params.id,
  }).catch(() => {});

  return ok(res, r, { message: 'Đã xoá bàn' });
});

// =============================================================================
//  5. Chuyển bàn  ★ TÍNH NĂNG CHÍNH ★
//  POST /api/tables/move
//  Body: { from_table_id, to_table_id, reason? }
//
//  Điều kiện:
//   • Bàn nguồn phải có ít nhất 1 order status IN ('pending','serving')
//   • Bàn đích KHÔNG được có order nào đang mở
//   • from ≠ to
//
//  Toàn bộ thực hiện trong 1 DB transaction:
//   1. Lock 2 bàn (FOR UPDATE, theo thứ tự ID để tránh deadlock)
//   2. Kiểm tra điều kiện nguồn/đích
//   3. UPDATE tất cả orders: đổi table_id + table_code
//   4. Ghi table_move_logs
// =============================================================================
exports.moveTable = asyncHandler(async (req, res) => {
  const { from_table_id, to_table_id, reason } = req.body || {};

  // ── Validate input ──────────────────────────────────────────────────────────
  const errs = [];
  if (!from_table_id) errs.push('from_table_id: bắt buộc');
  if (!to_table_id)   errs.push('to_table_id: bắt buộc');
  if (errs.length) throw ApiError.validation('Dữ liệu không hợp lệ', errs);

  const fromId = String(from_table_id).trim();
  const toId   = String(to_table_id).trim();
  if (fromId === toId)
    throw ApiError.badRequest('Bàn nguồn và bàn đích không được trùng nhau');

  // ── Transaction ─────────────────────────────────────────────────────────────
  const result = await db.transaction(async (client) => {

    // 1. Lock cả 2 bàn theo thứ tự id từ điển → tránh deadlock khi 2 request song song
    await client.query(
      `SELECT id FROM tables
       WHERE id = ANY($1::uuid[])
       ORDER BY id
       FOR UPDATE`,
      [[fromId, toId]]
    );

    // 2a. Kiểm tra bàn NGUỒN
    const { rows: fromRows } = await client.query(
      `SELECT id, code FROM tables WHERE id = $1`,
      [fromId]
    );
    if (!fromRows.length)
      throw ApiError.notFound(`Bàn nguồn (id=${fromId}) không tồn tại`);
    const srcTable = fromRows[0];

    // Bàn nguồn phải đang có order mở (= "occupied")
    const { rows: openOrders } = await client.query(
      `SELECT id, code, status, total_amount
       FROM orders
       WHERE table_id = $1 AND status IN ('pending','serving')
       ORDER BY created_at`,
      [fromId]
    );
    if (!openOrders.length)
      throw ApiError.conflict(
        `Bàn "${srcTable.code}" không có order nào đang mở — không cần chuyển bàn`
      );

    // 2b. Kiểm tra bàn ĐÍCH
    const { rows: toRows } = await client.query(
      `SELECT id, code FROM tables WHERE id = $1`,
      [toId]
    );
    if (!toRows.length)
      throw ApiError.notFound(`Bàn đích (id=${toId}) không tồn tại`);
    const dstTable = toRows[0];

    // Bàn đích phải trống (= "available")
    const { rows: dstOpen } = await client.query(
      `SELECT id FROM orders
       WHERE table_id = $1 AND status IN ('pending','serving') LIMIT 1`,
      [toId]
    );
    if (dstOpen.length)
      throw ApiError.conflict(
        `Bàn "${dstTable.code}" đang có khách — chỉ được chuyển tới bàn trống`
      );

    // 3. Chuyển tất cả orders chưa đóng sang bàn đích
    const { rows: movedOrders } = await client.query(
      `UPDATE orders
       SET table_id   = $1,
           table_code = $2,
           updated_at = NOW()
       WHERE table_id = $3
         AND status IN ('pending','serving')
       RETURNING id, code, status, total_amount`,
      [dstTable.id, dstTable.code, srcTable.id]
    );

    // 4. Ghi lịch sử vào table_move_logs
    await client.query(
      `INSERT INTO table_move_logs
         (from_table_id, from_table_code, to_table_id, to_table_code,
          moved_by_id, moved_by_name, orders_moved, reason)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
      [
        srcTable.id, srcTable.code,
        dstTable.id, dstTable.code,
        req.user?.id   || null,
        req.user?.full_name || null,
        movedOrders.length,
        reason || null,
      ]
    );

    return {
      from_table:   { id: srcTable.id,  code: srcTable.code  },
      to_table:     { id: dstTable.id,  code: dstTable.code  },
      orders_moved: movedOrders,
      orders_count: movedOrders.length,
    };
  });

  // ── Audit log (fire-and-forget) ─────────────────────────────────────────────
  LogModel.write({
    user_id:   req.user?.id,
    user_name: req.user?.full_name,
    action:    'MOVE_TABLE',
    entity:    'TABLE',
    entity_id: result.from_table.id,
    details: {
      from: result.from_table.code,
      to:   result.to_table.code,
      orders_moved: result.orders_count,
      reason: reason || null,
    },
  }).catch(() => {});

  return ok(res, result, {
    message: `Đã chuyển ${result.orders_count} order từ bàn "${result.from_table.code}" sang "${result.to_table.code}"`,
  });
});

// =============================================================================
//  6. Danh sách Zone
//  GET /api/tables/zones
// =============================================================================
exports.listZones = asyncHandler(async (_req, res) => {
  const zones = await db.query(
    `SELECT * FROM table_zones WHERE is_active = TRUE ORDER BY sort_order, name`
  );
  return ok(res, zones);
});

// =============================================================================
//  7. Lịch sử chuyển bàn (admin)
//  GET /api/tables/move-logs?from=ISO&to=ISO&page=1&limit=50
// =============================================================================
exports.getMoveLog = asyncHandler(async (req, res) => {
  const { from, to, table_code, page, limit } = req.query;
  const conds = [], params = [];

  if (from)       { params.push(from);             conds.push(`ml.created_at >= $${params.length}`); }
  if (to)         { params.push(to);               conds.push(`ml.created_at <= $${params.length}`); }
  if (table_code) {
    params.push(table_code);
    conds.push(`(ml.from_table_code = $${params.length} OR ml.to_table_code = $${params.length})`);
  }
  const where = conds.length ? `WHERE ${conds.join(' AND ')}` : '';

  const rows = await db.query(
    `SELECT ml.*
     FROM table_move_logs ml
     ${where}
     ORDER BY ml.created_at DESC`,
    params
  );

  const r = paginateArray(rows, { page, limit });
  return paged(res, { ...r, message: `Lịch sử chuyển bàn (${r.total})` });
});
