// =============================================================================
//  statController.js  — Thống kê doanh thu cho Admin/Cashier Dashboard
// =============================================================================
const db = require('../database/db');
const { ok, asyncHandler, ApiError } = require('../utils/response');

// ─── GET /api/stats/overview ──────────────────────────────────────────────────
// Query: ?from=ISO&to=ISO&cashier_id=UUID
// Mặc định: hôm nay (00:00 → 23:59)
exports.overview = asyncHandler(async (req, res) => {
  let { from, to, cashier_id } = req.query;
  if (!from) from = new Date(new Date().setHours(0, 0, 0, 0)).toISOString();
  if (!to)   to   = new Date(new Date().setHours(23, 59, 59, 999)).toISOString();

  const params = [from, to];
  let cashierFilter = '';
  if (cashier_id) {
    params.push(cashier_id);
    cashierFilter = ` AND cashier_id = $${params.length}`;
  }

  // Tổng quan
  const summary = await db.queryOne(
    `SELECT
       COUNT(*)::int                          AS invoice_count,
       COALESCE(SUM(final_amount),0)::numeric AS total_revenue,
       COALESCE(AVG(final_amount),0)::numeric AS avg_invoice,
       COALESCE(SUM(discount),0)::numeric     AS total_discount,
       COALESCE(SUM(vat_amount),0)::numeric   AS total_vat
     FROM invoices
     WHERE created_at BETWEEN $1 AND $2 ${cashierFilter}`,
    params
  );

  // Doanh thu theo giờ
  const byHour = await db.query(
    `SELECT EXTRACT(HOUR FROM created_at)::int    AS hour,
            COALESCE(SUM(final_amount),0)::numeric AS revenue,
            COUNT(*)::int                          AS count
     FROM invoices
     WHERE created_at BETWEEN $1 AND $2 ${cashierFilter}
     GROUP BY 1 ORDER BY 1`,
    params
  );

  // Doanh thu theo phương thức thanh toán
  const byPaymentMethod = await db.query(
    `SELECT payment_method,
            COUNT(*)::int                          AS count,
            COALESCE(SUM(final_amount),0)::numeric AS revenue
     FROM invoices
     WHERE created_at BETWEEN $1 AND $2 ${cashierFilter}
     GROUP BY 1 ORDER BY revenue DESC`,
    params
  );

  // Top 10 món bán chạy
  const topItems = await db.query(
    `SELECT ii.item_name                           AS name,
            SUM(ii.quantity)::int                   AS qty,
            MAX(ii.price)::numeric                  AS price,
            COALESCE(SUM(ii.total_price),0)::numeric AS revenue
     FROM invoice_items ii
     JOIN invoices i ON i.id = ii.invoice_id
     WHERE i.created_at BETWEEN $1 AND $2 ${cashierFilter}
     GROUP BY ii.item_name
     ORDER BY qty DESC LIMIT 10`,
    params
  );

  // Thống kê theo zone bàn
  const byZone = await db.query(
    `SELECT t.zone,
            COUNT(DISTINCT i.id)::int               AS invoice_count,
            COALESCE(SUM(i.final_amount),0)::numeric AS revenue
     FROM invoices i
     JOIN orders o   ON o.id = i.order_id
     JOIN tables t   ON t.id = o.table_id
     WHERE i.created_at BETWEEN $1 AND $2 ${cashierFilter}
     GROUP BY t.zone
     ORDER BY revenue DESC`,
    params
  );

  // Orders đang mở hiện tại
  const openOrders = await db.queryOne(
    `SELECT COUNT(*)::int               AS count,
            COALESCE(SUM(total_amount),0)::numeric AS total
     FROM orders
     WHERE status IN ('pending','serving')`
  );

  return ok(res, { summary, byHour, byPaymentMethod, topItems, byZone, openOrders }, {
    meta: { from, to, cashier_id: cashier_id || null },
  });
});

// ─── GET /api/stats/daily ─────────────────────────────────────────────────────
// Query: ?days=14 (1..90)
exports.daily = asyncHandler(async (req, res) => {
  const days = Math.min(Math.max(parseInt(req.query.days || 14), 1), 90);
  const rows = await db.query(
    `SELECT DATE(created_at)                      AS day,
            COUNT(*)::int                          AS invoice_count,
            COALESCE(SUM(final_amount),0)::numeric AS revenue,
            COALESCE(SUM(total_amount - final_amount),0)::numeric AS discount_total
     FROM invoices
     WHERE created_at >= NOW() - ($1 || ' days')::interval
     GROUP BY 1 ORDER BY 1`,
    [String(days)]
  );
  return ok(res, rows, { meta: { days } });
});

// ─── GET /api/stats/monthly ───────────────────────────────────────────────────
// Query: ?year=2025  (mặc định: năm hiện tại)
exports.monthly = asyncHandler(async (req, res) => {
  const year = parseInt(req.query.year || new Date().getFullYear());
  if (year < 2000 || year > 2100) throw ApiError.badRequest('year không hợp lệ');

  const rows = await db.query(
    `SELECT EXTRACT(MONTH FROM created_at)::int    AS month,
            COUNT(*)::int                           AS invoice_count,
            COALESCE(SUM(final_amount),0)::numeric  AS revenue
     FROM invoices
     WHERE EXTRACT(YEAR FROM created_at) = $1
     GROUP BY 1 ORDER BY 1`,
    [year]
  );
  return ok(res, rows, { meta: { year } });
});
