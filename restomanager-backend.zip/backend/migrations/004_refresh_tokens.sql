-- =============================================================================
--  004_refresh_tokens.sql
--  Bổ sung bảng refresh_tokens để hỗ trợ JWT refresh flow an toàn.
--
--  Luồng hoạt động:
--    1. POST /auth/login  → trả access_token (15m) + refresh_token (7d)
--    2. POST /auth/refresh → nhận refresh_token, trả access_token mới
--    3. POST /auth/logout  → revoke refresh_token (xoá khỏi bảng)
--
--  Idempotent: chạy lại không gây lỗi.
-- =============================================================================

CREATE TABLE IF NOT EXISTS refresh_tokens (
    id         BIGSERIAL    PRIMARY KEY,
    user_id    UUID         NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash TEXT         NOT NULL UNIQUE,   -- SHA-256 của token thực (không lưu raw)
    user_agent TEXT,                            -- browser/device hint
    ip         TEXT,
    expires_at TIMESTAMPTZ  NOT NULL,
    revoked_at TIMESTAMPTZ,                     -- NULL = còn hợp lệ
    created_at TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- Index để lookup nhanh khi verify + cleanup hết hạn
CREATE INDEX IF NOT EXISTS refresh_tokens_user_idx    ON refresh_tokens(user_id);
CREATE INDEX IF NOT EXISTS refresh_tokens_expires_idx ON refresh_tokens(expires_at);

-- Auto-cleanup tokens đã hết hạn > 1 ngày (chạy bởi pg_cron nếu có, hoặc cleanup thủ công)
-- Ghi chú: nếu muốn tự động thì kích hoạt pg_cron và uncomment dòng dưới:
-- SELECT cron.schedule('cleanup-refresh-tokens', '0 3 * * *',
--   'DELETE FROM refresh_tokens WHERE expires_at < NOW() - INTERVAL ''1 day''');
