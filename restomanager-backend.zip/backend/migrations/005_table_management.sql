-- =============================================================================
--  005_table_management.sql
--  Tăng cường quản lý bàn: hỗ trợ nhiều zone linh hoạt, ghi lịch sử
--  chuyển bàn, và meta-data bổ sung.
--
--  Thay đổi:
--   1. tables.zone  → mở rộng CHECK ra thành TEXT tự do (admin tự tạo zone)
--   2. Bảng mới table_zones     — danh mục zone do admin quản lý
--   3. Bảng mới table_move_logs — lịch sử mỗi lần chuyển bàn
--
--  Idempotent.
-- =============================================================================

-- ── 1. Bảng danh mục ZONE ─────────────────────────────────────────────────────
-- Cho phép admin thêm zone mới (vip, rooftop, private, ...) mà không cần
-- sửa code. Zone mặc định được seed sẵn.
CREATE TABLE IF NOT EXISTS table_zones (
    id         UUID   PRIMARY KEY DEFAULT gen_random_uuid(),
    code       TEXT   UNIQUE NOT NULL,    -- indoor, outdoor, vip, garden, ...
    name       TEXT   NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    is_active  BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO table_zones (code, name, sort_order) VALUES
  ('t1',      'Tầng 1',         1),
  ('garden',  'Sân vườn',       2),
  ('vip',     'VIP',            3),
  ('indoor',  'Trong nhà',      4),
  ('outdoor', 'Ngoài trời',     5)
ON CONFLICT (code) DO NOTHING;

-- ── 2. Bổ sung cột notes cho bảng tables ─────────────────────────────────────
ALTER TABLE tables ADD COLUMN IF NOT EXISTS notes TEXT;

-- ── 3. Bảng lịch sử CHUYỂN BÀN ──────────────────────────────────────────────
-- Mỗi lần gọi POST /tables/move thành công → ghi 1 dòng vào đây.
-- Dữ liệu dùng để audit, xem lại lý do chuyển, báo cáo vận hành.
CREATE TABLE IF NOT EXISTS table_move_logs (
    id              BIGSERIAL    PRIMARY KEY,
    from_table_id   UUID         REFERENCES tables(id) ON DELETE SET NULL,
    from_table_code TEXT         NOT NULL,
    to_table_id     UUID         REFERENCES tables(id) ON DELETE SET NULL,
    to_table_code   TEXT         NOT NULL,
    moved_by_id     UUID         REFERENCES users(id) ON DELETE SET NULL,
    moved_by_name   TEXT,
    orders_moved    INTEGER      NOT NULL DEFAULT 0,  -- số đơn được chuyển
    reason          TEXT,                              -- ghi chú lý do (tuỳ chọn)
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS table_move_logs_from_idx ON table_move_logs(from_table_id);
CREATE INDEX IF NOT EXISTS table_move_logs_to_idx   ON table_move_logs(to_table_id);
CREATE INDEX IF NOT EXISTS table_move_logs_date_idx ON table_move_logs(created_at);

-- ── 4. Mở rộng CHECK constraint zone trên bảng tables ────────────────────────
-- Xoá constraint cũ (nếu có) để zone không bị giới hạn cứng trong migration
DO $$
DECLARE cname TEXT;
BEGIN
  SELECT conname INTO cname
  FROM pg_constraint
  WHERE conrelid = 'tables'::regclass
    AND contype = 'c'
    AND pg_get_constraintdef(oid) ILIKE '%zone%';
  IF cname IS NOT NULL THEN
    EXECUTE format('ALTER TABLE tables DROP CONSTRAINT %I', cname);
    RAISE NOTICE 'Dropped zone constraint: %', cname;
  END IF;
END $$;

-- Zone giờ là TEXT tự do, validate ở tầng application (tham chiếu table_zones)
-- (Không thêm FK để tránh migrate dữ liệu cũ bị reject)
